const s='{% block sw_cms_block_category_cards %} <div class="sw-cms-block-category-cards"> <slot name="card1"></slot> <slot name="card2"></slot> <slot name="card3"></slot> <slot name="card4"></slot> </div> {% endblock %}',c={template:s};export{c as default};
//# sourceMappingURL=index-D18u_49A.js.map
