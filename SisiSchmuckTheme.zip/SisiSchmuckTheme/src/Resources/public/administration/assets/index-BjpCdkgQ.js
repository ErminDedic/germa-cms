const e='{% block sw_cms_block_banner_image %} <div class="sw-cms-block-banner-image"> <slot name="content"></slot> </div> {% endblock %}',n={template:e};export{n as default};
//# sourceMappingURL=index-BjpCdkgQ.js.map
