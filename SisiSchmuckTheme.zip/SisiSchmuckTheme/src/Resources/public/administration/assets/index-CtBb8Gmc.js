const s='{% block sw_cms_block_four_materials %} <div class="sw-cms-block-four-materials"> <slot name="materials1"></slot> <slot name="materials2"></slot> <slot name="materials3"></slot> <slot name="materials4"></slot> </div> {% endblock %}',l={template:s};export{l as default};
//# sourceMappingURL=index-CtBb8Gmc.js.map
