const o='{% block sw_cms_block_four_icon_cards %} <div class="sw-cms-block-four-icon-cards"> <slot name="iconcard1"></slot> <slot name="iconcard2"></slot> <slot name="iconcard3"></slot> <slot name="iconcard4"></slot> </div> {% endblock %}',c={template:o};export{c as default};
//# sourceMappingURL=index-CO_z7u_V.js.map
