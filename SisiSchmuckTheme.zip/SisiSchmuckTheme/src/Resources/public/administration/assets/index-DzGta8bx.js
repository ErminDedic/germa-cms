const e=`{% block sw_cms_element_timeline_preview %} <div class="sw-cms-el-preview-timeline"> <img :src="assetFilter('/sisischmucktheme/static/images/cms-timeline-preview.png')"> </div> {% endblock %}`,s={template:e,computed:{assetFilter(){return Shopware.Filter.getByName("asset")}}};export{s as default};
//# sourceMappingURL=index-DzGta8bx.js.map
