const t='{% block sw_cms_block_image_text_list %} <div class="sw-cms-block-image-text-list"> <slot name="content"></slot> </div> {% endblock %}',s={template:t};export{s as default};
//# sourceMappingURL=index-D7j13bYX.js.map
