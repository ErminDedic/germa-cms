const e='<component v-if="value" :is="value.tag" v-html="value.text" class="sw-cms-component-headline" />',a={name:"sw-cms-heading",template:e,props:["value"]};export{a as S};
//# sourceMappingURL=index-dCkrET7S.js.map
