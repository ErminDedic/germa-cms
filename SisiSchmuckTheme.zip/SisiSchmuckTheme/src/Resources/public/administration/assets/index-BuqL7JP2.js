const c='{% block sw_cms_block_accordion %} <div class="sw-cms-block-accordion"> <slot name="content"></slot> </div> {% endblock %}',o={template:c};export{o as default};
//# sourceMappingURL=index-BuqL7JP2.js.map
