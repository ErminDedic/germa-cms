const s='{% block sw_cms_block_product_highlights_preview %} <div class="sw-cms-preview-product-highlights"> <sw-cms-el-preview-product-highlights /> </div> {% endblock %}',e={template:s};export{e as default};
//# sourceMappingURL=index-CBdTnJOa.js.map
