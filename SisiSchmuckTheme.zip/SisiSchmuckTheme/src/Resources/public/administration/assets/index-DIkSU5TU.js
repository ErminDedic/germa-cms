const e=`{% block sw_cms_element_image_focus_point_preview %} <div class="sw-cms-el-preview-image-focus-point"> <img :src="assetFilter('/sisischmucktheme/static/images/cms-image-focus-point-preview.png')"> </div> {% endblock %}`,s={template:e,computed:{assetFilter(){return Shopware.Filter.getByName("asset")}}};export{s as default};
//# sourceMappingURL=index-DIkSU5TU.js.map
