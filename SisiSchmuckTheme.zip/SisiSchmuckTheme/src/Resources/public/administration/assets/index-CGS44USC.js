const t='{% block sw_cms_block_title %} <div class="sw-cms-block-title"> <slot name="content"></slot> </div> {% endblock %}',l={template:t};export{l as default};
//# sourceMappingURL=index-CGS44USC.js.map
