const e='{% block sw_cms_el_config_sisi_bundles %} <div class="sw-cms-el-config-sisi-bundles"> No config </div> {% endblock %}',{Mixin:s}=Shopware,i={template:e,mixins:[s.getByName("cms-element")],created(){this.createdComponent()},methods:{createdComponent(){this.initElementConfig("sisi-bundles")}}};export{i as default};
//# sourceMappingURL=index-DtXxamb4.js.map
