const e='{% block sw_cms_block_preview_image_focus_point %} <div class="sw-cms-preview-image-focus-point"> <sw-cms-el-preview-image-focus-point /> </div> {% endblock %}',s={template:e};export{s as default};
//# sourceMappingURL=index-C8atY4lg.js.map
