const s='{% block sw_cms_block_sisi_bundles %} <div class="sw-cms-block-sisi-bundles"> <slot name="content"></slot> </div> {% endblock %}',l={template:s};export{l as default};
//# sourceMappingURL=index-5CT-4JsT.js.map
