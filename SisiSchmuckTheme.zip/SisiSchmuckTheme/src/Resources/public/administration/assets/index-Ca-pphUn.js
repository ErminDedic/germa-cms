const e=`{% block sw_cms_element_category_card_preview %} <div class="sw-cms-el-preview-category-card"> <img :src="assetFilter('/sisischmucktheme/static/images/cms-category-card-preview.png')"> </div> {% endblock %}`,s={template:e,computed:{assetFilter(){return Shopware.Filter.getByName("asset")}}};export{s as default};
//# sourceMappingURL=index-Ca-pphUn.js.map
