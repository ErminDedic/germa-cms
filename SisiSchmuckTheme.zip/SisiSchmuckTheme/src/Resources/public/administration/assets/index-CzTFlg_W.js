const e=`{% block sw_cms_block_preview_category_cards %} <div class="sw-cms-preview-category-cards"> <img :src="assetFilter('/sisischmucktheme/static/images/cms-category-cards-preview.png')"> </div> {% endblock %}`,s={template:e,computed:{assetFilter(){return Shopware.Filter.getByName("asset")}}};export{s as default};
//# sourceMappingURL=index-CzTFlg_W.js.map
