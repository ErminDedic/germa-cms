const e=`{% block sw_cms_element_sisi_bundles_preview %} <div class="sw-cms-el-preview-sisi-bundles"> <img :src="assetFilter('/sisischmucktheme/static/images/cms-sisi-bundles-preview.png')"> </div> {% endblock %}`,s={template:e,computed:{assetFilter(){return Shopware.Filter.getByName("asset")}}};export{s as default};
//# sourceMappingURL=index-BSfJ6SAz.js.map
