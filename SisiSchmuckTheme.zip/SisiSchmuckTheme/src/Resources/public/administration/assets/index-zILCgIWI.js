const e=`{% block sw_cms_element_title_preview %} <div class="sw-cms-el-preview-title"> <img :src="assetFilter('/sisischmucktheme/static/images/cms-title-preview.png')"> </div> {% endblock %}`,t={template:e,computed:{assetFilter(){return Shopware.Filter.getByName("asset")}}};export{t as default};
//# sourceMappingURL=index-zILCgIWI.js.map
