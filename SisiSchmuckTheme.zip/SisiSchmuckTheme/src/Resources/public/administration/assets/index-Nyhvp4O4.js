const c='{% block sw_cms_block_four_icon_cards %} <div class="sw-cms-block-preview-four-icon-cards"> <div> <sw-cms-el-preview-icon-card /> </div> <div> <sw-cms-el-preview-icon-card /> </div> <div> <sw-cms-el-preview-icon-card /> </div> <div> <sw-cms-el-preview-icon-card /> </div> </div> {% endblock %}',i={template:c};export{i as default};
//# sourceMappingURL=index-Nyhvp4O4.js.map
