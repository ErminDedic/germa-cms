const t='{% block sw_cms_block_product_highlights %} <div class="sw-cms-block-product-highlights"> <slot name="content"></slot> </div> {% endblock %}',s={template:t};export{s as default};
//# sourceMappingURL=index-CGHD9XiL.js.map
