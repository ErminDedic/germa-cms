const e=`{% block sw_cms_element_banner_image_preview %} <div class="sw-cms-el-preview-banner-image"> <img :src="assetFilter('/sisischmucktheme/static/images/cms-banner-image.png')"> </div> {% endblock %}`,s={template:e,computed:{assetFilter(){return Shopware.Filter.getByName("asset")}}};export{s as default};
//# sourceMappingURL=index-Dq2hmJHN.js.map
