const e='{% block sw_cms_block_title_preview %} <div class="sw-cms-preview-title"> <sw-cms-el-preview-title /> </div> {% endblock %}',t={template:e};export{t as default};
//# sourceMappingURL=index-BVy1gvrk.js.map
