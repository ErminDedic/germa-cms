const e=`{% block sw_cms_element_accordion_preview %} <div class="sw-cms-el-preview-accordion"> <img :src="assetFilter('/sisischmucktheme/static/images/cms-accordion-preview.png')"> </div> {% endblock %}`,s={template:e,computed:{assetFilter(){return Shopware.Filter.getByName("asset")}}};export{s as default};
//# sourceMappingURL=index-CVtMFOrH.js.map
