const t='{% block sw_cms_block_image_with_products %} <div class="sw-cms-block-image-with-products"> <slot name="imageproduct1"></slot> <slot name="imageproduct2"></slot> </div> {% endblock %}',o={template:t};export{o as default};
//# sourceMappingURL=index-BQZJvu0u.js.map
