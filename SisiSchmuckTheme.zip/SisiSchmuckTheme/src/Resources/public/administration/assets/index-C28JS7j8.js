const e=`{% block sw_cms_block_image_with_products_left %} <div class="sw-cms-block-preview-image-with-products-left"> <img :src="assetFilter('/sisischmucktheme/administration/images/image-with-product-slider-left.png')"> </div> {% endblock %}`,t={template:e,computed:{assetFilter(){return Shopware.Filter.getByName("asset")}}};export{t as default};
//# sourceMappingURL=index-C28JS7j8.js.map
