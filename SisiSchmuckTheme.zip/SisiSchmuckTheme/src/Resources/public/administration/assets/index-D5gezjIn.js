const e='{% block sw_cms_block_timeline %} <div class="sw-cms-block-timeline"> <slot name="content"></slot> </div> {% endblock %}',t={template:e};export{t as default};
//# sourceMappingURL=index-D5gezjIn.js.map
