const e='{% block sw_cms_element_sisi_bundles %} <div class="sw-cms-el-sisi-bundles"> Sisi bundles </div> {% endblock %}',{Mixin:s}=Shopware,i={template:e,mixins:[s.getByName("cms-element")],created(){this.createdComponent()},methods:{createdComponent(){this.initElementConfig("sisi-bundles")}}};export{i as default};
//# sourceMappingURL=index-BQAEQxFI.js.map
