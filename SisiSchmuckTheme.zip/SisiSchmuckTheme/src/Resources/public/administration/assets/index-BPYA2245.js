const s='{% block sw_cms_block_three_cards %} <div class="sw-cms-block-three-cards"> <slot name="card1"></slot> <slot name="card2"></slot> <slot name="card3"></slot> </div> {% endblock %}',c={template:s};export{c as default};
//# sourceMappingURL=index-BPYA2245.js.map
