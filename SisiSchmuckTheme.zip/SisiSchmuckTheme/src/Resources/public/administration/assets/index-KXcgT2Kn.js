const e='{% block sw_cms_block_image_text_list_preview %} <div class="sw-cms-preview-image-text-list"> <sw-cms-el-preview-image-text-list /> </div> {% endblock %}',t={template:e};export{t as default};
//# sourceMappingURL=index-KXcgT2Kn.js.map
