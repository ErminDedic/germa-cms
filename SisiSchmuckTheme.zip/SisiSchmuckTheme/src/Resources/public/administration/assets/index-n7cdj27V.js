const e='{% block sw_cms_block_preview_timeline %} <div class="sw-cms-preview-timeline"> <sw-cms-el-preview-timeline /> </div> {% endblock %}',i={template:e};export{i as default};
//# sourceMappingURL=index-n7cdj27V.js.map
