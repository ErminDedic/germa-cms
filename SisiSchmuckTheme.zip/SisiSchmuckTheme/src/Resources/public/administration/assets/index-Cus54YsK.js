const e='{% block sw_cms_block_four_materials %} <div class="sw-cms-block-preview-four-materials"> <div> <sw-cms-el-preview-materials /> </div> <div> <sw-cms-el-preview-materials /> </div> <div> <sw-cms-el-preview-materials /> </div> <div> <sw-cms-el-preview-materials /> </div> </div> {% endblock %}',s={template:e};export{s as default};
//# sourceMappingURL=index-Cus54YsK.js.map
