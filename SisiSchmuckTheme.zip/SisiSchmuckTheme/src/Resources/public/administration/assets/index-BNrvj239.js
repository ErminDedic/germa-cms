const e='{% block sw_cms_block_banner_image_preview %} <div class="sw-cms-preview-banner-image"> <sw-cms-el-preview-banner-image /> </div> {% endblock %}',s={template:e};export{s as default};
//# sourceMappingURL=index-BNrvj239.js.map
