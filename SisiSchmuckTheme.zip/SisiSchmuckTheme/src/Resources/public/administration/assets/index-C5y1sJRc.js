const e=`{% block sw_cms_element_timeline_config %} <div class="sw-cms-el-config-timeline"> {# Items #} <repeater :fields="element.config.fields.value" @update:fields="(newValue) => element.config.fields.value = newValue" formName="timeline-form" :defaultValue="defaultValue" :label="$tc('sw-cms.elements.timeline.config.tabsLabel')" :blockName="$tc('sw-cms.elements.timeline.config.blockName')" :addButtonText="$tc('sw-cms.elements.timeline.config.addButton')"> </repeater> </div> {% endblock %}`,{Mixin:t}=Shopware,i={template:e,mixins:[t.getByName("cms-element")],data(){return{defaultValue:{headline:"1950",content:`
                    <p>
                        Aufgrund des steigendes Produktionsaufkommens zieht die Firma 13 Jahre später, 
                        im Jahr 1963, in das neu errichtete Firmengebäude in München-Nymphenburg um. 
                        Fünf Jahre später erweitert sich die Produktion zusätzlich um die Herstellung 
                        mechanischer Uhrwerke und die Zahl der Beschäftigten steigt auf über 60 
                        Mitarbeiter an.
                    </p>`,signatureText:"Handwerkskunst seit 1950"}}},created(){this.createdComponent()},methods:{createdComponent(){this.initElementConfig("timeline"),this.initElementData("timeline")}}};export{i as default};
//# sourceMappingURL=index-C5y1sJRc.js.map
