const e=`{% block sw_cms_block_image_with_products %} <div class="sw-cms-block-preview-image-with-product-box"> <img :src="assetFilter('/sisischmucktheme/administration/images/image-with-product-slider.png')"> </div> {% endblock %}`,t={template:e,computed:{assetFilter(){return Shopware.Filter.getByName("asset")}}};export{t as default};
//# sourceMappingURL=index-xLzYZP-a.js.map
