const s='{% block sw_cms_block_sisi_bundles_preview %} <div class="sw-cms-preview-sisi-bundles"> <sw-cms-el-preview-sisi-bundles /> </div> {% endblock %}',e={template:s};export{e as default};
//# sourceMappingURL=index-CPvfqs_Z.js.map
