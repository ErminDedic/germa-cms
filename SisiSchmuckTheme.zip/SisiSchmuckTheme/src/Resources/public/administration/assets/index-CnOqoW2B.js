const t='{% block sw_cms_block_image_with_products_left %} <div class="sw-cms-block-image-with-products-left"> <slot name="imageproduct2"></slot> <slot name="imageproduct1"></slot> </div> {% endblock %}',o={template:t};export{o as default};
//# sourceMappingURL=index-CnOqoW2B.js.map
