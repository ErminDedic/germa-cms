const e='{% block sw_cms_block_reviews %} <div class="sw-cms-block-preview-reviews"> <sw-cms-el-preview-reviews /> </div> {% endblock %}',s={template:e};export{s as default};
//# sourceMappingURL=index-D8ry6amL.js.map
