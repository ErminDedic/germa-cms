const s='{% block sw_cms_block_reviews %} <div class="sw-cms-block-reviews"> <slot name="content"></slot> </div> {% endblock %}',e={template:s};export{e as default};
//# sourceMappingURL=index-BnXMe_6R.js.map
