const e='{% block sw_cms_block_newsletter_minimal %} <div class="sw-cms-block-preview-newsletter-minimal"> <sw-cms-el-preview-newsletter-minimal /> </div> {% endblock %}',l={template:e};export{l as default};
//# sourceMappingURL=index-B_Vs2bNd.js.map
