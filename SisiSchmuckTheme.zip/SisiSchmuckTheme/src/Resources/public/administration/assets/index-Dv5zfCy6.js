const c='{% block sw_cms_block_preview_accordion %} <div class="sw-cms-preview-accordion"> <sw-cms-el-preview-accordion /> </div> {% endblock %}',e={template:c};export{e as default};
//# sourceMappingURL=index-Dv5zfCy6.js.map
