const o='{% block sw_cms_block_image_focus_point %} <div class="sw-cms-block-image-focus-point"> <slot name="content"></slot> </div> {% endblock %}',s={template:o};export{s as default};
//# sourceMappingURL=index-DW8JuxCI.js.map
