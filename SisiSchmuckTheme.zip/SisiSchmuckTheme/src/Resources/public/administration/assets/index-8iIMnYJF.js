const e='{% block sw_cms_block_newsletter_minimal %} <div class="sw-cms-block-newsletter-minimal"> <slot name="content"></slot> </div> {% endblock %}',t={template:e};export{t as default};
//# sourceMappingURL=index-8iIMnYJF.js.map
