const e='{% block sw_cms_block_three_cards %} <div class="sw-cms-block-preview-three-cards"> <div> <sw-cms-el-preview-card /> </div> <div> <sw-cms-el-preview-card /> </div> <div> <sw-cms-el-preview-card /> </div> </div> {% endblock %}',c={template:e};export{c as default};
//# sourceMappingURL=index-CVlDzUue.js.map
