Shopware.Component.register('sw-cms-preview-reviews', () => import('./preview'));
Shopware.Component.register('sw-cms-block-reviews', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'reviews',
    label: 'sw-cms.blocks.sisi.reviews.label',
    category: 'sisi',
    component: 'sw-cms-block-reviews',
    previewComponent: 'sw-cms-preview-reviews',
    defaultConfig: {
        marginTop: '20px',
        marginBottom: '20px',
        marginLeft: '0px',
        marginRight: '0px',
        sizingMode: 'boxed'
    },
    slots: {
        'content': 'reviews'
    }
});
