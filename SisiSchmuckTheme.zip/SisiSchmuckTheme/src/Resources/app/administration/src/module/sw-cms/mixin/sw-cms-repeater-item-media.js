const { Mixin } = Shopware;

Mixin.register('sw-cms-repeater-item-media', {

    inject: ['repositoryFactory'],

    data() {
        return {
            mediaModalIsOpen: false,
            currentMediaTarget: '',
            mediaEntities: {},
            cmsPageState: Shopware.Store.get('cmsPage'),
            uniqueId: null
        };
    },

    computed: {
        mediaRepository() {
            return this.repositoryFactory.create('media');
        },
    },

    async created() {
        // generate unique ID for this component instance
        this.uniqueId = crypto.randomUUID
            ? crypto.randomUUID()
            : Math.random().toString(36).substring(2, 10);

        if (this.itemValue) {
            for (const key of Object.keys(this.itemValue)) {
                const mediaId = this.itemValue[key]?.id || this.itemValue[key]?.mediaId;
                if (mediaId) {
                    this.mediaEntities[key] = await this.mediaRepository.get(mediaId, Shopware.Context.api);
                }
            }
        }
    },

    methods: {
        uploadTag(target) {
            return `repeater-item-${target}-${this.index}-${this.uniqueId}`;
        },

        previewSource(target) {
            return this.mediaEntities[target] || null;
        },

        async onMediaUpload(targetId, target) {
            const mediaEntity = await this.mediaRepository.get(targetId, Shopware.Context.api);

            if (!this.itemValue[target] || this.itemValue[target] === null) {
                this.itemValue = { 
                    ...this.itemValue, 
                    [target]: {} 
                };
            }

            this.itemValue[target].id = mediaEntity.id;
            this.itemValue[target].url = mediaEntity.url;
            this.itemValue[target].mimeType = mediaEntity.mimeType;
            this.itemValue[target].mediaType = mediaEntity.mediaType?.name || null;

            this.mediaEntities = { 
                ...this.mediaEntities, 
                [target]: mediaEntity 
            };
        },

        onMediaRemove(target) {
            if (this.itemValue[target]) {
                this.itemValue[target].id = null;
                this.itemValue[target].url = null;
                this.itemValue[target].mimeType = null;
                this.itemValue[target].mediaType = null;
            }
            this.mediaEntities = { ...this.mediaEntities, [target]: null };
        },

        onModalMediaRemove() {
            this.onMediaRemove(this.currentMediaTarget);
        },

        async onMediaSelectionChange(mediaItems) {
            if (!mediaItems.length) return;

            const item = mediaItems[0];
            const mediaEntity = await this.mediaRepository.get(item.id, Shopware.Context.api);

            if (!this.itemValue[this.currentMediaTarget]) {
                this.itemValue[this.currentMediaTarget] = {};
            }

            this.itemValue[this.currentMediaTarget].id = mediaEntity.id;
            this.itemValue[this.currentMediaTarget].url = mediaEntity.url;
            this.itemValue[this.currentMediaTarget].mimeType = mediaEntity.mimeType;
            this.itemValue[this.currentMediaTarget].mediaType = mediaEntity.mediaType?.name || null;


            this.mediaEntities = { 
                ...this.mediaEntities, 
                [this.currentMediaTarget]: mediaEntity 
            };

            this.mediaModalIsOpen = false;
        },

        onOpenMediaModal(target) {
            this.currentMediaTarget = target;
            this.mediaModalIsOpen = true;
        },

        onCloseMediaModal() {
            this.mediaModalIsOpen = false;
        }
    }
});
