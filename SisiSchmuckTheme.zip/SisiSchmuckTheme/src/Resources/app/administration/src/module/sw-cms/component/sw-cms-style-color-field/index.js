import template from './sw-cms-style-color-field.html.twig';
import './sw-cms-style-color-field.scss';

const { Component } = Shopware;

Component.register('sw-cms-style-color-field', {
    template,

    props: {
        label: {
            type: String
        },

        helpText: {
            type: String
        },

        value: {
            type: Object,
            default: {
                themeColor: 'Primary',
                color: '',
                isInherited: true
            }
        }
    },

    computed: {
        colorValue:{
            get() { return this.value; },
            set(colorValue) { this.$emit('input', colorValue) }
        },

        colorOptions() {
            return [
                { id: 1, value: 'none', label: 'None', },
                { id: 2, value: 'primary', label: 'Primary', },
                { id: 3, value: 'secondary', label: 'Secondary', },
                { id: 4, value: 'info', label: 'Info', },
                { id: 5, value: 'success', label: 'Success', },
                { id: 6, value: 'warning', label: 'Warning', },
                { id: 7, value: 'danger', label: 'Danger', },
                { id: 8, value: 'light', label: 'Light', },
                { id: 9, value: 'dark', label: 'Dark', },
            ];
        },
    },

    methods: {
        toggleInheritance() {
            this.colorValue.isInherited = !this.colorValue.isInherited
        }
    }
});
