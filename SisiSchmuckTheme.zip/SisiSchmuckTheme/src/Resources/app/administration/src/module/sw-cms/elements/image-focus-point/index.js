Shopware.Component.register('sw-cms-el-preview-image-focus-point', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-image-focus-point', () => import('./config'));
Shopware.Component.register('sw-cms-el-image-focus-point', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'image-focus-point',
    label: 'sw-cms.elements.image-focus-point.label',
    component: 'sw-cms-el-image-focus-point',
    configComponent: 'sw-cms-el-config-image-focus-point',
    previewComponent: 'sw-cms-el-preview-image-focus-point',
    defaultConfig: {
        // Text
        preheadline: {
            source: 'static',
            value: 'BESTÄNDIG DESIGN',
        },
        headline: {
            source: 'static',
            value: {
                text: 'Ewige <u>Eleganz</u>',
                tag: 'h1'
            },
        },
        button: {     
            source: 'static',
            value: {
                url: '',
                text: 'Lorem ipsum',
                title: '',
                type: 'primary',
                size: 'md',
                outline: false,
                block: false,
                newTab: false,
            }     
        },
        
        // Badge media
        badgeMedia: {
            source: 'static',
            value: null,
            entity: {
                name: 'media'
            }
        },

        previewImage: {
            source: 'static',
            value: null,
            entity: {
                name: 'media'
            }
        },
        
        // Image pin
        media: {
            source: 'static',
            value: null,
            entity: {
                name: 'media'
            }
        },
        product: {
            source: 'static',
            value: null,
            required: true,
            entity: {
                name: 'product',
                criteria: new Shopware.Data.Criteria(1, 25).addAssociation('cover'),
            },
        },
        focusPoint: {
            source: 'static',
            value: {
                x: null,
                y: null
            }
        }
    },
    defaultData: {
        boxLayout: 'standard',
        product: null,
    },
    collect: Shopware.Service('cmsService').getCollectFunction(),
});
