import template from './sw-cms-el-review-item.html.twig';
import './sw-cms-el-review-item.scss';

export default {
    name: 'sw-cms-el-review-item',

    template,

    props: ['item'],
}
