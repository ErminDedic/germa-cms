import './component';
import './config';
import './preview';

Shopware.Service('cmsService').registerCmsElement({
    name: 'sisi-video',
    label: 'sw-cms.elements.sisi-video.label',
    component: 'sw-cms-el-sisi-video',
    configComponent: 'sw-cms-el-config-sisi-video',
    previewComponent: 'sw-cms-el-preview-sisi-video',
    defaultConfig: {
        media: {
            source: 'static',
            value: null,
            required: true,
            entity: {
                name: 'media',
            },
        },
        displayMode: {
            source: 'static',
            value: 'standard',
        },
        minHeight: {
            source: 'static',
            value: '340px',
        },
        verticalAlign: {
            source: 'static',
            value: null,
        },
        horizontalAlign: {
            source: 'static',
            value: null,
        },
    },
});
