import template from './sw-cms-el-config.html.twig';

const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element'),
    ],

    data() {
        return {
            textEditorExcludedButtons: [
                'text-alignment',
                'format'
            ]
        };
    },

    computed: {
        horizontalAlignmentOptions() {
            return [
                { id: 1, value: 'left', label: this.$tc('sw-cms.elements.title.config.alignOptionLeft'), },
                { id: 2, value: 'center', label: this.$tc('sw-cms.elements.title.config.alignOptionCenter'), },
                { id: 3, value: 'right', label: this.$tc('sw-cms.elements.title.config.alignOptionRight'), },
            ];
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('title');
        },
    },
};
