import template from './sw-cms-el.html.twig';
import './sw-cms-el.scss';

import ButtonField from '../../../component/sw-cms-link-field/usage';
 
const { Mixin } = Shopware;

export default {
    template,

    inject: ['feature'],

    mixins: [
        Mixin.getByName('cms-element')
    ],

    computed: {
        // Content
       
        headline() {
            return this.element.config.headline.value;
        },

        text() {
            return this.element.config.text.value;
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('card');
            this.initElementData('card');
        },
    }
};
