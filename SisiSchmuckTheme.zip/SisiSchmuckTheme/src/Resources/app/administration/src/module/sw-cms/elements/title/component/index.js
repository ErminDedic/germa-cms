import template from './sw-cms-el.html.twig';
import './sw-cms-el.scss';

import SwCmsHeading from '../../../component/sw-cms-heading-field/usage';

const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element'),
    ],

    components: {
        'sw-cms-heading': SwCmsHeading
    },

    computed: {
        // Content
        preheadline() {
            return this.element.config.preheadline.value;
        },

        headline() {
            return this.element.config.headline.value;
        },

        subheadline() {
            return this.element.config.subheadline.value;
        },

        text() {
            return this.element.config.text.value;
        },

        signatureText() {
            return this.element.config.signatureText.value;
        },

        // Settings
        alignContent() {
            return this.element.config.alignContent.value;
        },
        
        alignContentMobile() {
            return this.element.config.alignContentMobile.value;
        },

        isDisplaySize() {
            return this.element.config.isDisplaySize.value;
        },

        // Styles
        color() {
            return this.element.config.color.value;
        },

        // Element classes and styles
        elementClasses() {
            return {
                ['is--align-' + this.alignContent]: true,
                ['is--align-mobile-' + this.alignContentMobile]: true,
                ['is--display']: this.isDisplaySize,
                ['text-' + this.color.themeColor]: this.color.isInherited,
            };
        },

        elementStyles() {
            const styles = {};

            // Add color styles if color is not inherited
            if (!this.color.isInherited) {
                styles.color = this.color.color;
            }

            return styles;
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('title');
        },
    },
};
