Shopware.Component.register('sw-cms-preview-image-with-products-left', () => import('./preview'));
Shopware.Component.register('sw-cms-block-image-with-products-left', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'image-with-products-left',
    label: 'sw-cms.blocks.sisi.image-with-products-left.label',
    category: 'sisi',
    component: 'sw-cms-block-image-with-products-left',
    previewComponent: 'sw-cms-preview-image-with-products-left',
    defaultConfig: {
        marginBottom: '20px',
        marginTop: '20px',
        marginLeft: '0px',
        marginRight: '0px',
        sizingMode: 'boxed'
    },
    slots: {
        imageproduct1: 'image',
        imageproduct2: 'product-slider',
    }
});
