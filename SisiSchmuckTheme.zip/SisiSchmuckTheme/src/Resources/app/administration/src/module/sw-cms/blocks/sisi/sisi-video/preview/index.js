import template from './sw-cms-preview-sisi-video.html.twig';
import './sw-cms-preview-sisi-video.scss';

const { Component } = Shopware;

Component.register('sw-cms-preview-sisi-video', {
    template,

    computed: {
        assetFilter() {
            return Shopware.Filter.getByName('asset');
        }
    }
});
