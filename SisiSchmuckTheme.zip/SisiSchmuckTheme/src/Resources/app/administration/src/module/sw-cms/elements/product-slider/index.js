const cmsElements = Shopware.Service('cmsService').getCmsElementRegistry();

const cmsElProductSlider = cmsElements['product-slider'];
const cmsElProductSliderDefaultConfig = cmsElProductSlider.defaultConfig;

cmsElProductSliderDefaultConfig.displayMode.value = 'contain';
cmsElProductSliderDefaultConfig.boxLayout.value = 'image';
cmsElProductSliderDefaultConfig.elMinWidth.value = '400px';
