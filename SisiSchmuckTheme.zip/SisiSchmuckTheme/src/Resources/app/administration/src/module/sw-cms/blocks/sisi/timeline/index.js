Shopware.Component.register('sw-cms-preview-timeline', () => import('./preview'));
Shopware.Component.register('sw-cms-block-timeline', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'timeline',
    label: 'sw-cms.blocks.sisi.timeline.label',
    category: 'sisi',
    component: 'sw-cms-block-timeline',
    previewComponent: 'sw-cms-preview-timeline',
    defaultConfig: {
        marginTop: '20px',
        marginBottom: '20px',
        marginLeft: '0px',
        marginRight: '0px',
        sizingMode: 'boxed'
    },
    slots: {
        content: {
            type: 'timeline',
        },
    }
});
