import template from './sw-cms-el-preview.html.twig';
import './sw-cms-el-preview.scss';

export default {
    template,
};