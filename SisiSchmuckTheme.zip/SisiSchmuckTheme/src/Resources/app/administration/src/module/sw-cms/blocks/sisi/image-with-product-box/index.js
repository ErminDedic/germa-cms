Shopware.Component.register('sw-cms-preview-image-with-product-box', () => import('./preview'));
Shopware.Component.register('sw-cms-block-image-with-product-box', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'image-with-product-box',
    label: 'sw-cms.blocks.sisi.image-with-product-box.label',
    category: 'sisi',
    component: 'sw-cms-block-image-with-product-box',
    previewComponent: 'sw-cms-preview-image-with-product-box',
    defaultConfig: {
        marginBottom: '20px',
        marginTop: '20px',
        marginLeft: '0px',
        marginRight: '0px',
        sizingMode: 'boxed'
    },
    slots: {
        imageproduct1: 'image',
        imageproduct2: 'product-box',
        imageproduct3: 'product-box',
        imageproduct4: 'product-box',
        imageproduct5: 'product-box',
    }
});
