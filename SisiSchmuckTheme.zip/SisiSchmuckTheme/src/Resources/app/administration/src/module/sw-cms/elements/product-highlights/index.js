Shopware.Component.register('sw-cms-el-preview-product-highlights', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-product-highlights', () => import('./config'));
Shopware.Component.register('sw-cms-el-product-highlights', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'product-highlights',
    label: 'sw-cms.elements.product-highlights.label',
    component: 'sw-cms-el-product-highlights',
    configComponent: 'sw-cms-el-config-product-highlights',
    previewComponent: 'sw-cms-el-preview-product-highlights',
    defaultConfig: {
        textLeft: {
            source: 'static',
            value: `
                <h2>Lorem Ipsum dolor sit amet</h2>
                <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, 
                sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, 
                sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. 
                Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
            `.trim(),
        },
        fields: {
            source: 'static',
            value: [],
        },
        media: {
            source: 'static',
            value: null,
            entity: {
                name: 'media'
            }
        },

        headline: {
            source: 'static',
            value: 'Lorem ipsum',
        },
    }
});
