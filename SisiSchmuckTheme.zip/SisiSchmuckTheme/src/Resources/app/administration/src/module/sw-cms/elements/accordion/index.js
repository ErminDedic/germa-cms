Shopware.Component.register('sw-cms-el-preview-accordion', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-accordion', () => import('./config'));
Shopware.Component.register('sw-cms-el-accordion', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'accordion',
    label: 'sw-cms.elements.accordion.label',
    component: 'sw-cms-el-accordion',
    previewComponent: 'sw-cms-el-preview-accordion',
    configComponent: 'sw-cms-el-config-accordion',
    defaultConfig: {
        fields: {
            source: 'static',
            value: []
        },
        variant: {
            source: 'static',
            value: 'regular'
        }
    }
});