import template from './sw-cms-el-config.html.twig';

const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element'),
        Mixin.getByName('cms-element-media')
    ],

    computed: {
        variantOptions() {
            return [
                { id: 1, value: 'variant1', label: this.$tc('sw-cms.elements.category-card.config.variantOption1'), },
                { id: 2, value: 'variant2', label: this.$tc('sw-cms.elements.category-card.config.variantOption2'), },
                { id: 3, value: 'variant3', label: this.$tc('sw-cms.elements.category-card.config.variantOption3'), },
                { id: 4, value: 'variant4', label: this.$tc('sw-cms.elements.category-card.config.variantOption4'), },
            ];
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('category-card');
            this.initElementData('category-card');
        },
    }
};
