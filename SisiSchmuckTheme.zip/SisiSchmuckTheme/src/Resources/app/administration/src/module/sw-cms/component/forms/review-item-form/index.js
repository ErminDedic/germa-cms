import template from './template.html.twig';

const { Component, Mixin } = Shopware;

Component.register('review-item-form', {
    template,

    mixins: [
        Mixin.getByName('sw-cms-repeater-item-media')
    ],

    props: {
        value: { type: Object, required: true },
        index: { type: Number }
    },

    computed: {
        itemValue: {
            get() { return this.value; },
            set(val) { this.$emit('input', val); }
        }
    }
});
