Shopware.Component.register('sw-cms-el-preview-icon-card', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-icon-card', () => import('./config'));
Shopware.Component.register('sw-cms-el-icon-card', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'icon-card',
    label: 'sw-cms.elements.icon-card.label',
    component: 'sw-cms-el-icon-card',
    configComponent: 'sw-cms-el-config-icon-card',
    previewComponent: 'sw-cms-el-preview-icon-card',
    defaultConfig: {
        media: {
            source: 'static',
            value: null,
            entity: {
                name: 'media'
            }
        },
        preview: {
            source: 'static',
            value: null,
            entity: {
                name: 'media'
            }
        },
        headline: {
            source: 'static',
            value: 'Lorem ipsum',
        },
        text: {
            source: 'static',
            value: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
        },
        button: {     
            source: 'static',
            value: "",   
        },
    }
});
