import template from './sw-cms-el.html.twig';
import './sw-cms-el.scss';
 
const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element')
    ],

    computed: {
        // Content
        headline() {
            return this.element.config.headline.value;
        },

        text() {
            return this.element.config.text.value;
        },

        button() {
            return this.element.config.button.value;
        },

        media() {
            return this.element.config.media.value;
        },

        reigt() {
            return this.element.config.media.value;
        },

        // Settings
        hasContentLeft() {
            return this.element.config.hasContentLeft.value;
        },

        hasContentRight() {
            return this.element.config.hasContentRight.value;
        },

        rightBackground() {
            return this.element.config.rightBackground.value;
        },

        leftBackground() {
            return this.element.config.leftBackground.value;
        },

        hasMedia() {
            return this.element.config.hasMedia.value;
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('banner-image');
            this.initElementData('banner-image');
        },
    }
};
