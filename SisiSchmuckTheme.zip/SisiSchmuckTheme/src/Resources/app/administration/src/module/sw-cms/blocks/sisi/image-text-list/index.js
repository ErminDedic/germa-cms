Shopware.Component.register('sw-cms-preview-image-text-list', () => import('./preview'));
Shopware.Component.register('sw-cms-block-image-text-list', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'image-text-list',
    label: 'sw-cms.blocks.sisi.image-text-list.label',
    category: 'sisi',
    component: 'sw-cms-block-image-text-list',
    previewComponent: 'sw-cms-preview-image-text-list',
    defaultConfig: {
        marginBottom: '20px',
        marginTop: '20px',
        marginLeft: '0',
        marginRight: '0',
        sizingMode: 'boxed',
    },
    slots: {
        content: 'image-text-list',
    },
});
