import template from './sw-cms-el.html.twig';
import './sw-cms-el.scss';

const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element')
    ],

    computed: {
        // Content
        textLeft() {
            return this.element.config.textLeft.value;
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('seo-text');
            this.initElementData('seo-text');
        },
    }
};
