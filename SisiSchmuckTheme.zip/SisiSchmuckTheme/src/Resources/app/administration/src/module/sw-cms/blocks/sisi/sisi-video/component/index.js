import template from './sw-cms-block-sisi-video.html.twig';

const { Component } = Shopware;

Component.register('sw-cms-block-sisi-video', {
    template,
});
