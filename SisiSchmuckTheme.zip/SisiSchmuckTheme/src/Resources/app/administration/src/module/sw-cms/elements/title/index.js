Shopware.Component.register('sw-cms-el-preview-title', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-title', () => import('./config'));
Shopware.Component.register('sw-cms-el-title', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'title',
    label: 'sw-cms.elements.title.label',
    component: 'sw-cms-el-title',
    configComponent: 'sw-cms-el-config-title',
    previewComponent: 'sw-cms-el-preview-title',
    defaultConfig: {
        // Content
        preheadline: {
            source: 'static',
            value: '',
        },
        headline: {
            source: 'static',
            value: {
                text: 'Lorem Ipsum',
                tag: 'h2'
            },
        },
        subheadline: {
            source: 'static',
            value: '',
        },
        text: {
            source: 'static',
            value: '',
        },
        signatureText: {
            source: 'static',
            value: '',
        },

        // Settings
        alignContent: {
            source: 'static',
            value: 'center',
        },
        alignContentMobile: {
            source: 'static',
            value: 'center',
        },
        isDisplaySize: {
            source: 'static',
            value: true,
        },

        // Styles
        color: {
            source: 'static',
            value: {
                themeColor: '',
                color: '#000000',
                isInherited: true
            }
        },
    },
});
