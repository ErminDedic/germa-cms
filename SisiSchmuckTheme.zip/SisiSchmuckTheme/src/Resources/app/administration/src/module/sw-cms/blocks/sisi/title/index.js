Shopware.Component.register('sw-cms-preview-title', () => import('./preview'));
Shopware.Component.register('sw-cms-block-title', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'title',
    label: 'sw-cms.blocks.sisi.title.label',
    category: 'sisi',
    component: 'sw-cms-block-title',
    previewComponent: 'sw-cms-preview-title',
    defaultConfig: {
        marginBottom: '20px',
        marginTop: '20px',
        marginLeft: '0',
        marginRight: '0',
        sizingMode: 'boxed',
    },
    slots: {
        content: 'title',
    },
});
