Shopware.Component.register('sw-cms-el-preview-newsletter-minimal', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-newsletter-minimal', () => import('./config'));
Shopware.Component.register('sw-cms-el-newsletter-minimal', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'newsletter-minimal',
    label: 'sw-cms.elements.newsletterMinimal.label',
    component: 'sw-cms-el-newsletter-minimal',
    configComponent: 'sw-cms-el-config-newsletter-minimal',
    previewComponent: 'sw-cms-el-preview-newsletter-minimal',
    defaultConfig: {
        media: {
            source: 'static',
            value: null,
            entity: {
                name: 'media'
            }
        },
        headline: {
            source: 'static',
            value: {
                text: 'Lorem Ipsum',
                tag: 'h3'
            },
        },
        text: {
            source: 'static',
            value: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nostrum quo harum similique?'
        },
        backgroundImage: {
            source: 'static',
            value: null,
            entity: {
                name: 'media'
            }
        },
    },
});
