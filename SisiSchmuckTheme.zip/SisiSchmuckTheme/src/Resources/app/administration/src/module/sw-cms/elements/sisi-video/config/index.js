import template from './sw-cms-el-config-sisi-video.html.twig';
import './sw-cms-el-config-sisi-video.scss';

const { Component, Mixin } = Shopware;

Component.register('sw-cms-el-config-sisi-video', {
    template,

    inject: ['repositoryFactory'],

    mixins: [
        Mixin.getByName('cms-element'),
        Mixin.getByName('cms-element-media')
    ],

    props: {
        fileAccept: {
            type: String,
            required: false,
            default: '*/*',
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('sisi-video');
            this.initElementData('sisi-video');
        },

        onChangeMinHeight(value) {
            this.element.config.minHeight.value = value === null ? '' : value;

            this.$emit('element-update', this.element);
        },

        onChangeDisplayMode(value) {
            if (value === 'cover') {
                this.element.config.verticalAlign.value = null;
            }

            this.$emit('element-update', this.element);
        },
    },
});
