import template from './sw-cms-el-config.html.twig';

const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element'),
        Mixin.getByName('cms-element-media')
    ],

    data() {
        return {
            // Buttons in repeater default values
            defaultValue: {
                url: '',
                text: 'Lorem ipsum',
                title: 'Lorem ipsum',
                type: 'primary',
                size: 'md',
                outline: false,
                block: false,
                newTab: false,
            } 
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('materials');
            this.initElementData('materials');
        },
    }
};
