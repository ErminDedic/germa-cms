import template from './sw-cms-heading-field.html.twig';
import './sw-cms-heading-field.scss';

const { Component } = Shopware;

Component.register('sw-cms-heading-field', {
    template,

    props: {
        label: {
            type: String
        },
        
        value: {
            type: Object,
            default: {
                text: '',
                tag: '',                     
            }
        },
    },

    computed: {
        headingValue:{
            get() { return this.value; },
            set(headingValue) { this.$emit('input', headingValue) }
        },

        headingTagOptions() {
            return [
                { id: 1, value: 'h1', label: 'h1', },
                { id: 2, value: 'h2', label: 'h2', },
                { id: 3, value: 'h3', label: 'h3', },
                { id: 4, value: 'h4', label: 'h4', },
                { id: 5, value: 'h5', label: 'h5', },
                { id: 6, value: 'h6', label: 'h6', },
            ];
        },
    }
});
