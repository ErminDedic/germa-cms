import './component';
import './preview';

Shopware.Service('cmsService').registerCmsBlock({
    name: 'sisi-video',
    label: 'sw-cms.blocks.sisi.sisi-video.label',
    category: 'sisi',
    component: 'sw-cms-block-sisi-video',
    previewComponent: 'sw-cms-preview-sisi-video',
    defaultConfig: {
        marginBottom: '20px',
        marginTop: '20px',
        marginLeft: '0px',
        marginRight: '0px',
        sizingMode: 'boxed',
    },
    slots: {
        content: 'sisi-video',
    },
});
