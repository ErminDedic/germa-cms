Shopware.Component.register('sw-cms-preview-product-highlights', () => import('./preview'));
Shopware.Component.register('sw-cms-block-product-highlights', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'product-highlights',
    label: 'sw-cms.blocks.sisi.product-highlights.label',
    category: 'sisi',
    component: 'sw-cms-block-product-highlights',
    previewComponent: 'sw-cms-preview-product-highlights',
    defaultConfig: {
        marginBottom: '20px',
        marginTop: '20px',
        marginLeft: '0',
        marginRight: '0',
        sizingMode: 'boxed',
    },
    slots: {
        content: 'product-highlights',
    },
});
