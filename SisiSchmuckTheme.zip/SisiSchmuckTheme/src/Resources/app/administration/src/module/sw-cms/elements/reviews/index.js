Shopware.Component.register('sw-cms-el-preview-reviews', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-reviews', () => import('./config'));
Shopware.Component.register('sw-cms-el-reviews', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'reviews',
    label: 'sw-cms.elements.reviews.label',
    component: 'sw-cms-el-reviews',
    configComponent: 'sw-cms-el-config-reviews',
    previewComponent: 'sw-cms-el-preview-reviews',
    defaultConfig: {
        reviews: {
            source: 'static',
            value: []
        },
    },
});
