Shopware.Component.register('sw-cms-preview-sisi-bundles', () => import('./preview'));
Shopware.Component.register('sw-cms-block-sisi-bundles', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'sisi-bundles',
    label: 'sw-cms.blocks.sisi.sisi-bundles.label',
    category: 'sisi',
    component: 'sw-cms-block-sisi-bundles',
    previewComponent: 'sw-cms-preview-sisi-bundles',
    defaultConfig: {
        marginBottom: '20px',
        marginTop: '20px',
        marginLeft: '0',
        marginRight: '0',
        sizingMode: 'boxed',
    },
    slots: {
        content: 'sisi-bundles',
    },
});
