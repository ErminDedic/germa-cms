Shopware.Component.register('sw-cms-el-preview-seo-text', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-seo-text', () => import('./config'));
Shopware.Component.register('sw-cms-el-seo-text', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'seo-text',
    label: 'sw-cms.elements.seo-text.label',
    component: 'sw-cms-el-seo-text',
    configComponent: 'sw-cms-el-config-seo-text',
    previewComponent: 'sw-cms-el-preview-seo-text',
    defaultConfig: {
        textLeft: {
            source: 'static',
            value: `
                <h2>Lorem Ipsum dolor sit amet</h2>
                <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, 
                sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, 
                sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. 
                Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
            `.trim(),
        },
    }
});
