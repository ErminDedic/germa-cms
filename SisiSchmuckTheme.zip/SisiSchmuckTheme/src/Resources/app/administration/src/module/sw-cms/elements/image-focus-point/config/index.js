import template from './sw-cms-el-config.html.twig';
import './sw-cms-el-config.scss';

const { Mixin } = Shopware;
const { Criteria } = Shopware.Data;

export default {
    template,

    compatConfig: Shopware.compatConfig,

    inject: ['repositoryFactory'],

    emits: ['element-update'],

    mixins: [
        Mixin.getByName('cms-element'),
        Mixin.getByName('cms-element-media')
    ],

    computed: {
        productRepository() {
            return this.repositoryFactory.create('product');
        },

        productSelectContext() {
            const context = { ...Shopware.Context.api };
            context.inheritance = true;

            return context;
        },

        productCriteria() {
            const criteria = new Criteria(1, 25);
            criteria.addAssociation('options.group');

            return criteria;
        },

        focusPointPositionStyle() {
            return {
                left: `${this.element.config.focusPoint.value.x}%`,
                top: `${this.element.config.focusPoint.value.y}%`,
                transform: 'translate(-50%, -50%)'
            };
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('image-focus-point');
        },

        onProductChange(productId) {
            if (!productId) {
                this.element.config.product.value = null;
                
                this.element.data.productId = null;
                this.element.data.product = null;
            } else {
                const criteria = new Criteria(1, 25);
                criteria.addAssociation('cover');
                criteria.addAssociation('options.group');

                this.productRepository.get(productId, this.productSelectContext, criteria).then((product) => {
                    this.element.config.product.value = productId;

                    this.element.data.productId = productId;
                    this.element.data.product = product;
                });
            }

            this.$emit('element-update', this.element);
        },

        handleClick(event) {
            const container = this.$refs.imageContainer;
            const rect = container.getBoundingClientRect();
    
            const clickX = event.clientX - rect.left;
            const clickY = event.clientY - rect.top;
    
            this.element.config.focusPoint.value.x = (clickX / rect.width) * 100;
            this.element.config.focusPoint.value.y = (clickY / rect.height) * 100;
        }
    },
};
