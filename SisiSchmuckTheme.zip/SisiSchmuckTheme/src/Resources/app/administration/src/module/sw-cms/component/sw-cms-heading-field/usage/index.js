import template from './sw-cms-heading.html.twig';
import './sw-cms-heading.scss';

export default {
    name: 'sw-cms-heading',

    template,

    props: ['value'],
}
