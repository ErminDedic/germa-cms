import template from './sw-cms-el.html.twig';
import './sw-cms-el.scss';
 
const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element')
    ],

    data() {
        return {
            currentActiveIndex: 0
        };
    },

    computed: {
        // Content
        fields() {
            return this.element.config.fields.value;
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('timeline');
            this.initElementData('timeline');
        },

        onChangeActiveIndex(index) {
            this.currentActiveIndex = index;
        },

        onPrevTab() {
            if(this.currentActiveIndex == 0)
                return;

            this.currentActiveIndex--;
        },

        onNextTab() {
            if(this.currentActiveIndex == this.fields.length - 1)
                return;

            this.currentActiveIndex++;
        }
    }
};
