import template from './sw-cms-config-divider.html.twig';
import './sw-cms-config-divider.scss';

const { Component } = Shopware;

Component.register('sw-cms-config-divider', {
    template,

    props: {
        label: {
            type: String
        },
    },
});
