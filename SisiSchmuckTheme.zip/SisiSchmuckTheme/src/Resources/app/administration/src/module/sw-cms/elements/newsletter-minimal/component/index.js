import template from './sw-cms-el.html.twig';
import './sw-cms-el.scss';

import SwCmsHeading from '../../../component/sw-cms-heading-field/usage';
import ButtonField from '../../../component/sw-cms-link-field/usage';
 
const { Mixin } = Shopware;

export default {
    template,

    inject: ['feature'],

    components: {
        'sw-cms-heading': SwCmsHeading,
        'button-field': ButtonField
    },

    mixins: [
        Mixin.getByName('cms-element')
    ],

    computed: {
        headline() {
            return this.element.config.headline.value;
        },

        text() {
            return this.element.config.text.value;
        },

        backgroundImage() {
            return this.element.config.backgroundImage.value;
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('newsletter-minimal');
            this.initElementData('newsletter-minimal');
        },
    }
};
