import template from './sw-cms-el.html.twig';
import './sw-cms-el.scss';

const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element'),
    ],

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('sisi-bundles');
        },
    },
};
