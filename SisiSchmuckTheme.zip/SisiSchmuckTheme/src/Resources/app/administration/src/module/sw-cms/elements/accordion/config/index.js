import template from './sw-cms-el-config.html.twig';

const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element')
    ],

    created() {
        this.createdComponent();
    },

    data() {
        return {
            // default values added to the newly added title
            defaultValue: {
                title: 'Lorem ipsum dolor sit amet',
                content: `
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Eligendi delectus iste vitae ipsum ipsam. 
                    Quae nostrum commodi eum saepe aut!`
                ,
            }
        }
    },

    methods: {
        createdComponent() {
            this.initElementConfig('accordion');
            this.initElementData('accordion');
        }
    }
};
