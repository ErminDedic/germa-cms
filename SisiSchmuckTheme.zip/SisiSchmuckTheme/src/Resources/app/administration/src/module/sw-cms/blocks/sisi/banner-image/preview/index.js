import template from './sw-cms-preview.html.twig';
import './sw-cms-preview.scss';

export default {
    template,
};
