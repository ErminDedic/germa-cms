import template from './sw-cms-el.html.twig';
import './sw-cms-el.scss';

import SwCmsHeading from '../../../component/sw-cms-heading-field/usage';
import SwCmsButton from '../../../component/sw-cms-link-field/usage';

const { Mixin, Filter } = Shopware;

export default {
    template,

    compatConfig: Shopware.compatConfig,

    mixins: [
        Mixin.getByName('cms-element'),
        Mixin.getByName('placeholder'),
    ],

    components: {
        'sw-cms-heading': SwCmsHeading,
        'sw-cms-button': SwCmsButton
    },

    computed: {
        // Text content
        preheadline() {
            return this.element.config.preheadline.value;
        },

        headline() {
            return this.element.config.headline.value;
        },

        button() {
            return this.element.config.button.value;
        },

        // Media
        media() {
            return this.element.config.media.value;
        },

        focusPointPositionStyle() {
            return {
                left: `${this.element.config.focusPoint.value.x}%`,
                top: `${this.element.config.focusPoint.value.y}%`,
                transform: 'translate(-50%, -50%)'
            };
        },

        // Product
        product() {
            if (!this.element?.data?.product) {
                return {
                    name: 'Lorem ipsum dolor',
                    description: `Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
                    sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat,
                    sed diam voluptua.`,
                    price: [
                        { gross: 19.9 },
                    ],
                    cover: {
                        media: {
                            url: '/administration/administration/static/img/cms/preview_mountain_small.jpg',
                            alt: 'Lorem Ipsum dolor',
                        },
                    },
                };
            }

            return this.element.data.product;
        },

        productMediaUrl() {
            if (this.product.cover && this.product.cover.media) {
                if (this.product.cover.media.id) {
                    return this.product.cover.media.url;
                }

                return this.assetFilter(this.product.cover.media.url);
            }

            return this.assetFilter('/administration/administration/static/img/cms/preview_mountain_small.jpg');
        },

        assetFilter() {
            return Filter.getByName('asset');
        },

        currencyFilter() {
            return Filter.getByName('currency');
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('image-focus-point');
            this.initElementData('image-focus-point');
        },
    },
};
