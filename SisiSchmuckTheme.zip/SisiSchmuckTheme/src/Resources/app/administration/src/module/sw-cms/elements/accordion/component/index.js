import template from './sw-cms-el.html.twig';
import './sw-cms-el.scss';
 
const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element')
    ],

    data() {
        return {
            currentActiveIndex: 0
        };
    },

    computed: {
        fields() {
            return this.element.config.fields.value;
        },

        variant() {
            return this.element.config.variant.value;
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('accordion');
            this.initElementData('accordion');
        },

        onChangeActiveIndex(index) {
            this.currentActiveIndex = index
        }
    }
};
