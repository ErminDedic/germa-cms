import template from './sw-cms-el.html.twig';
import './sw-cms-el.scss';

import ButtonField from '../../../component/sw-cms-link-field/usage';
 
const { Mixin } = Shopware;

export default {
    template,

    inject: ['feature'],

    mixins: [
        Mixin.getByName('cms-element')
    ],

    computed: {
        // Content
        media() {
            return this.element.config.media.value;
        },


        headline() {
            return this.element.config.headline.value;
        },

        text() {
            return this.element.config.text.value;
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('icon-card');
            this.initElementData('icon-card');
        },
    }
};
