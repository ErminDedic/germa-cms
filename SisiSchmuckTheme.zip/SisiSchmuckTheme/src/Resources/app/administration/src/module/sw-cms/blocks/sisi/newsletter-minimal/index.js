Shopware.Component.register('sw-cms-preview-newsletter-minimal', () => import('./preview'));
Shopware.Component.register('sw-cms-block-newsletter-minimal', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'newsletter-minimal',
    label: 'sw-cms.blocks.sisi.newsletterMinimal.label',
    category: 'sisi',
    component: 'sw-cms-block-newsletter-minimal',
    previewComponent: 'sw-cms-preview-newsletter-minimal',
    defaultConfig: {
        marginTop: '20px',
        marginBottom: '20px',
        marginLeft: '0px',
        marginRight: '0px',
        sizingMode: 'boxed'
    },
    slots: {
        'content': 'newsletter-minimal'
    }
});
