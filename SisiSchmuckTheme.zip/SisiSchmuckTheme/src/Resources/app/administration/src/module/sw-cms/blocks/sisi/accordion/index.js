Shopware.Component.register('sw-cms-preview-accordion', () => import('./preview'));
Shopware.Component.register('sw-cms-block-accordion', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'accordion',
    label: 'sw-cms.blocks.sisi.accordion.label',
    category: 'sisi',
    component: 'sw-cms-block-accordion',
    previewComponent: 'sw-cms-preview-accordion',
    defaultConfig: {
        marginTop: '20px',
        marginBottom: '20px',
        marginLeft: '0px',
        marginRight: '0px',
        sizingMode: 'boxed'
    },
    slots: {
        content: {
            type: 'accordion',
        },
    }
});
