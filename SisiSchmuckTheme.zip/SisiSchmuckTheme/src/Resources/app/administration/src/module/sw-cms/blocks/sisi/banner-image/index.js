Shopware.Component.register('sw-cms-preview-banner-image', () => import('./preview'));
Shopware.Component.register('sw-cms-block-banner-image', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'banner-image',
    label: 'sw-cms.blocks.sisi.banner-image.label',
    category: 'sisi',
    component: 'sw-cms-block-banner-image',
    previewComponent: 'sw-cms-preview-banner-image',
    defaultConfig: {
        marginBottom: '20px',
        marginTop: '20px',
        marginLeft: '0',
        marginRight: '0',
        sizingMode: 'boxed',
    },
    slots: {
        content: 'banner-image',
    },
});
