Shopware.Component.register('sw-cms-el-preview-card', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-card', () => import('./config'));
Shopware.Component.register('sw-cms-el-card', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'card',
    label: 'sw-cms.elements.card.label',
    component: 'sw-cms-el-card',
    configComponent: 'sw-cms-el-config-card',
    previewComponent: 'sw-cms-el-preview-card',
    defaultConfig: {
        headline: {
            source: 'static',
            value: 'Lorem ipsum',
        },
        text: {
            source: 'static',
            value: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
        },
        bg: {
            source: 'static',
            value: '',
        },
    }
});
