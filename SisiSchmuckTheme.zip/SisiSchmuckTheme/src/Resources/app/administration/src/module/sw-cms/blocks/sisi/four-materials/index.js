Shopware.Component.register('sw-cms-preview-four-materials', () => import('./preview'));
Shopware.Component.register('sw-cms-block-four-materials', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'four-materials',
    label: 'sw-cms.blocks.sisi.four-materials.label',
    category: 'sisi',
    component: 'sw-cms-block-four-materials',
    previewComponent: 'sw-cms-preview-four-materials',
    defaultConfig: {
        marginBottom: '20px',
        marginTop: '20px',
        marginLeft: '0px',
        marginRight: '0px',
        sizingMode: 'boxed'
    },
    slots: {
        materials1: 'materials',
        materials2: 'materials',
        materials3: 'materials',
        materials4: 'materials',
    }
});
