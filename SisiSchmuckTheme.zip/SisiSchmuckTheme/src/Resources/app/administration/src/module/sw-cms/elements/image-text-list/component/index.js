import template from './sw-cms-el.html.twig';
import './sw-cms-el.scss';
 
const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element')
    ],

    computed: {
        // Content
        textLeft() {
            return this.element.config.textLeft.value;
        },

        media() {
            return this.element.config.media.value;
        },
        // Settings
        hasContentLeft() {
            return this.element.config.hasContentLeft.value;
        },

        hasContentRight() {
            return this.element.config.hasContentRight.value;
        },

        hasMedia() {
            return this.element.config.hasMedia.value;
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('image-text-list');
            this.initElementData('image-text-list');
        },
    }
};
