import template from './sw-cms-link-field.html.twig';
import './sw-cms-link-field.scss';

const { Component } = Shopware;

Component.register('sw-cms-link-field', {
    template,

    props: {
        label: {
            type: String
        },

        type: {
            type: String,
            default: 'link'
        },
        
        value: {
            type: Object,
            default: {
                url: '',
                text: 'Lorem ipsum',
                title: 'Lorem ipsum',
                type: 'primary',
                size: 'md',
                outline: false,
                block: false,
                newTab: false,                        
            }
        },
    },

    computed: {
        linkValue:{
            get() { return this.value; },
            set(linkValue) { this.$emit('update:link', linkValue) }
        },

        typeOptions() {
            return [
                { id: 1, value: 'primary', label: 'primary', },
                { id: 2, value: 'secondary', label: 'secondary', },
                { id: 3, value: 'info', label: 'info', },
                { id: 4, value: 'success', label: 'success', },
                { id: 5, value: 'danger', label: 'danger', },
                { id: 6, value: 'warning', label: 'warning', },
                { id: 7, value: 'light', label: 'light', },
                { id: 8, value: 'dark', label: 'dark', },
                { id: 9, value: 'link', label: 'link', },
            ];
        },

        sizeOptions() {
            return [
                { id: 1, value: 'sm', label: 'sm', },
                { id: 2, value: 'md', label: 'md', },
                { id: 3, value: 'lg', label: 'lg', },
            ];
        },
    }
});
