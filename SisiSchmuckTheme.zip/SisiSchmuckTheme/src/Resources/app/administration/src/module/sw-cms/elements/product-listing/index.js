import './config';

const cmsElements = Shopware.Service('cmsService').getCmsElementRegistry();

const cmsElProductListing = cmsElements['product-listing'];
const cmsElProductListingDefaultConfig = cmsElProductListing.defaultConfig;

cmsElProductListing.defaultConfig = {
    ...cmsElProductListingDefaultConfig,
    disruptorShow: {
        source: 'static',
        value: false,
    },
    disruptorMedia: {
        source: 'static',
        value: null,
        entity: {
            name: 'media'
        }
    },
    disruptorHeadline: {
        source: 'static',
        value: '3er Ohrstecker',
    },
    disruptorText: {
        source: 'static',
        value: 'mit Süßwasserperle',
    },
    disruptorButton: {
        source: 'static',
        value: {
            url: '',
            text: 'JETZT KAUFEN',
            title: '',
            type: 'secondary',
            size: 'md',
            outline: false,
            block: false,
            newTab: false,
        }  
    }
};
