Shopware.Component.register('sw-cms-preview-category-cards', () => import('./preview'));
Shopware.Component.register('sw-cms-block-category-cards', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'category-cards',
    label: 'sw-cms.blocks.sisi.category-cards.label',
    category: 'sisi',
    component: 'sw-cms-block-category-cards',
    previewComponent: 'sw-cms-preview-category-cards',
    defaultConfig: {
        marginTop: '20px',
        marginBottom: '20px',
        marginLeft: '0px',
        marginRight: '0px',
        sizingMode: 'boxed'
    },
    slots: {
        card1: {
            type: 'category-card',
            default: {
                config: {
                    variant: {
                        source: 'static',
                        value: 'variant1'
                    },
                },
            },
        },
        card2: {
            type: 'category-card',
            default: {
                config: {
                    variant: {
                        source: 'static',
                        value: 'variant2'
                    },
                },
            },
        },
        card3: {
            type: 'category-card',
            default: {
                config: {
                    variant: {
                        source: 'static',
                        value: 'variant3'
                    },
                },
            },
        },
        card4: {
            type: 'category-card',
            default: {
                config: {
                    variant: {
                        source: 'static',
                        value: 'variant4'
                    },
                },
            },
        },
    }
});
