import template from './sw-cms-el-config.html.twig';
import './sw-cms-el-config.scss';

const { Mixin } = Shopware;

export default {
    template,

    compatConfig: Shopware.compatConfig,

    inject: ['repositoryFactory'],

    emits: ['element-update'],

    mixins: [
        Mixin.getByName('cms-element'),
        Mixin.getByName('cms-element-media')
    ],

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('newsletter-minimal');
            this.initElementData('newsletter-minimal');
        },
    }
};
