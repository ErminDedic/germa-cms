import template from './sw-cms-el.html.twig';
import './sw-cms-el.scss';
 
import SwCmsElReviewItem from './item';

const { Mixin, Store } = Shopware;

export default {
    template,

    components: {
        'review-item': SwCmsElReviewItem
    },

    mixins: [
        Mixin.getByName('cms-element')
    ],

    data() {
        return {
            visibleItems: 3,
            currentActiveItem: 0,
        };
    },

    computed: {
        currentDeviceView() {
            return Store.get('cmsPage').currentCmsDeviceView;
        },

        reviews() {
            return this.element.config.reviews.value.slice(this.currentActiveItem, this.currentActiveItem + this.visibleItems);
        },
    },

    created() {
        this.createdComponent();
    },

    watch: {
        cmsPageState: {
            deep: true,
            handler() {
                this.$forceUpdate();
            }
        },

        currentDeviceView() {
            setTimeout(() => {
                this.setVisibleItems();
            }, 400);
        },

        'element.config.numberOfItems.value': {
            deep: true,
            handler() {
                setTimeout(() => {
                    this.setVisibleItems();
                }, 400);
            }
        }
    },

    methods: {
        createdComponent() {
            this.initElementConfig('reviews');
            this.initElementData('reviews');
        },

        setVisibleItems() {
            if (this.currentDeviceView === 'mobile') {
                this.visibleItems = 1;
                return;
            }

            if (this.currentDeviceView === 'tablet-landscape') {
                this.visibleItems = 2;
                return;
            }

            this.visibleItems = 3;
        },

        // Slider functions
        onNext() {
            if (this.currentActiveItem + this.visibleItems >= this.element.config.reviews.value.length)
                return;

            this.currentActiveItem++;
        },

        onPrev() {
            if (this.currentActiveItem == 0)
                return;

            this.currentActiveItem--;
        },
    }
};
