Shopware.Component.register('sw-cms-el-preview-banner-image', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-banner-image', () => import('./config'));
Shopware.Component.register('sw-cms-el-banner-image', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'banner-image',
    label: 'sw-cms.elements.banner-image.label',
    component: 'sw-cms-el-banner-image',
    configComponent: 'sw-cms-el-config-banner-image',
    previewComponent: 'sw-cms-el-preview-banner-image',
    defaultConfig: {
        headline: {
            source: 'static',
            value: 'Anhänger',
        },
        text: {
            source: 'static',
            value: 'Elegante Details',
        },
        button: {     
            source: 'static',
            value: {
                url: '',
                text: 'JETZT KAUFEN',
                title: '',
                type: 'light',
                size: 'md',
                outline: false,
                block: false,
                newTab: false,
            }     
        },
        media: {
            source: 'static',
            value: null,
            entity: {
                name: 'media'
            }
        },
        leftBackground: {
            source: 'static',
            value: null,
            entity: {
                name: 'media'
            }
        },
        rightBackground: {
            source: 'static',
            value: null,
            entity: {
                name: 'media'
            }
        },
        hasContentLeft: {
            source: 'static',
            value: true,
        },
        hasMedia: {
            source: 'static',
            value: true,
        },
    }
});
