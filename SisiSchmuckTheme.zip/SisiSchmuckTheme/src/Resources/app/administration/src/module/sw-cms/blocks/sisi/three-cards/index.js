Shopware.Component.register('sw-cms-preview-three-cards', () => import('./preview'));
Shopware.Component.register('sw-cms-block-three-cards', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'three-cards',
    label: 'sw-cms.blocks.sisi.three-cards.label',
    category: 'sisi',
    component: 'sw-cms-block-three-cards',
    previewComponent: 'sw-cms-preview-three-cards',
    defaultConfig: {
        marginBottom: '20px',
        marginTop: '20px',
        marginLeft: '0px',
        marginRight: '0px',
        sizingMode: 'boxed'
    },
    slots: {
        card1: 'card',
        card2: 'card',
        card3: 'card',
    }
});
