Shopware.Component.register('sw-cms-el-preview-sisi-bundles', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-sisi-bundles', () => import('./config'));
Shopware.Component.register('sw-cms-el-sisi-bundles', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'sisi-bundles',
    label: 'sw-cms.elements.sisi-bundles.label',
    component: 'sw-cms-el-sisi-bundles',
    configComponent: 'sw-cms-el-config-sisi-bundles',
    previewComponent: 'sw-cms-el-preview-sisi-bundles',
    defaultConfig: {},
});
