Shopware.Component.register('sw-cms-el-preview-timeline', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-timeline', () => import('./config'));
Shopware.Component.register('sw-cms-el-timeline', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'timeline',
    label: 'sw-cms.elements.timeline.label',
    component: 'sw-cms-el-timeline',
    previewComponent: 'sw-cms-el-preview-timeline',
    configComponent: 'sw-cms-el-config-timeline',
    defaultConfig: {
        fields: {
            source: 'static',
            value: []
        }
    }
});