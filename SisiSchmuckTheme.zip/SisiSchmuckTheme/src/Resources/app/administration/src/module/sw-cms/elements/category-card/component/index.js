import template from './sw-cms-el.html.twig';
import './sw-cms-el.scss';

import SwCmsButton from '../../../component/sw-cms-link-field/usage';
 
const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element')
    ],

    components: {
        'sw-cms-button': SwCmsButton
    },

    computed: {
        // Content
        media() {
            return this.element.config.media.value;
        },

        headline() {
            return this.element.config.headline.value;
        },

        text() {
            return this.element.config.text.value;
        },

        button() {
            return this.element.config.button.value;
        },

        // Settings
        variant() {
            return this.element.config.variant.value;
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('category-card');
            this.initElementData('category-card');
        },
    }
};
