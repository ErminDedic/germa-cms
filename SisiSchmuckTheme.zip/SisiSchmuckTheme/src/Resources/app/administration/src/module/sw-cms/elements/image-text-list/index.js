Shopware.Component.register('sw-cms-el-preview-image-text-list', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-image-text-list', () => import('./config'));
Shopware.Component.register('sw-cms-el-image-text-list', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'image-text-list',
    label: 'sw-cms.elements.image-text-list.label',
    component: 'sw-cms-el-image-text-list',
    configComponent: 'sw-cms-el-config-image-text-list',
    previewComponent: 'sw-cms-el-preview-image-text-list',
    defaultConfig: {
        textLeft: {
            source: 'static',
            value: `
                <h2>Lorem Ipsum dolor sit amet</h2>
                <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, 
                sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, 
                sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. 
                Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
            `.trim(),
        },
        media: {
            source: 'static',
            value: null,
            entity: {
                name: 'media'
            }
        },
        hasContentLeft: {
            source: 'static',
            value: true,
        },
        hasMedia: {
            source: 'static',
            value: true,
        },
        button: {     
            source: 'static',
            value: "",   
        },
    }
});
