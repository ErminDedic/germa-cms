import template from './sw-cms-el-preview-sisi-video.html.twig';
import './sw-cms-el-preview-sisi-video.scss';

const { Component } = Shopware;

Component.register('sw-cms-el-preview-sisi-video', {
    template,

    computed: {
        assetFilter() {
            return Shopware.Filter.getByName('asset');
        }
    }
});
