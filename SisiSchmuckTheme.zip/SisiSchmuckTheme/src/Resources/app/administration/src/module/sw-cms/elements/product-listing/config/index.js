import template from './sw-cms-el-config.html.twig';

const { Component, Mixin } = Shopware;

Component.override('sw-cms-el-config-product-listing', {
    template,

    mixins: [
        Mixin.getByName('cms-element'),
        Mixin.getByName('cms-element-media')
    ],

    methods: {
        createdComponent() {
            this.initElementConfig('sw-cms-el-config-product-listing');
            this.initElementData('sw-cms-el-config-product-listing');
        },
    }
});
