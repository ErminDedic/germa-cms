import template from './sw-cms-el-config.html.twig';

const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element'),
    ],

    data() {
        return {
            // default values added to the newly added title
            defaultValue: {
                headline: '1950',
                content: `
                    <p>
                        Aufgrund des steigendes Produktionsaufkommens zieht die Firma 13 Jahre später, 
                        im Jahr 1963, in das neu errichtete Firmengebäude in München-Nymphenburg um. 
                        Fünf Jahre später erweitert sich die Produktion zusätzlich um die Herstellung 
                        mechanischer Uhrwerke und die Zahl der Beschäftigten steigt auf über 60 
                        Mitarbeiter an.
                    </p>`
                ,
                signatureText: 'Handwerkskunst seit 1950'
            }
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('timeline');
            this.initElementData('timeline');
        }
    }
};
