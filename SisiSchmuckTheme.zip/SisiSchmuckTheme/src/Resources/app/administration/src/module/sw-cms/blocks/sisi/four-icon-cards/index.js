Shopware.Component.register('sw-cms-preview-four-icon-cards', () => import('./preview'));
Shopware.Component.register('sw-cms-block-four-icon-cards', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'four-icon-cards',
    label: 'sw-cms.blocks.sisi.four-icon-cards.label',
    category: 'sisi',
    component: 'sw-cms-block-four-icon-cards',
    previewComponent: 'sw-cms-preview-four-icon-cards',
    defaultConfig: {
        marginBottom: '20px',
        marginTop: '20px',
        marginLeft: '0px',
        marginRight: '0px',
        sizingMode: 'boxed'
    },
    slots: {
        iconcard1: 'icon-card',
        iconcard2: 'icon-card',
        iconcard3: 'icon-card',
        iconcard4: 'icon-card',
    }
});
