Shopware.Component.register('sw-cms-el-preview-materials', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-materials', () => import('./config'));
Shopware.Component.register('sw-cms-el-materials', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'materials',
    label: 'sw-cms.elements.materials.label',
    component: 'sw-cms-el-materials',
    configComponent: 'sw-cms-el-config-materials',
    previewComponent: 'sw-cms-el-preview-materials',
    defaultConfig: {
        media: {
            source: 'static',
            value: null,
            entity: {
                name: 'media'
            }
        },
        headline: {
            source: 'static',
            value: 'Lorem ipsum',
        },
        text: {
            source: 'static',
            value: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
        },
    }
});
