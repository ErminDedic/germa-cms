const { Mixin } = Shopware;

Mixin.register('cms-element-media', {

    inject: ['repositoryFactory'],

    model: {
        prop: 'element',
        event: 'element-update',
    },

    props: {
        element: {
            type: Object,
            required: true,
        },
    },

    data() {
        return {
            mediaModalIsOpen: false,
            initialFolderId: null,
            currentMediaTarget: '',
        }
    },

    computed: {
        mediaRepository() {
            return this.repositoryFactory.create('media');
        },
    },

    methods: {
        uploadTag(target) {
            return `cms-element-${this.element.type}-config-${target}-${this.element.id}`;
        },

        previewSource(target) {
            if (this.element?.data[target]?.id) {
                return this.element.data[target];
            }

            return this.element.config[target].value;
        },

        // On media upload
        async onMediaUpload(targetId, target) {
            const mediaEntity = await this.mediaRepository.get(targetId);

            this.element.config[target].value = mediaEntity.id;
            this.element.config[target].source = 'static';
            this.updateElementData(mediaEntity);

            this.$emit('element-update', this.element);
        },

        // On media remove
        onMediaRemove(target) {
            this.currentMediaTarget = target;

            this.element.config[target].value = null;
            this.updateElementData();

            this.$emit('element-update', this.element);
        },

        // On media selection
        onSelectionChanges(mediaEntity, target = null) {
            if (target)
                this.currentMediaTarget = target;

            const media = mediaEntity[0];

            this.element.config[this.currentMediaTarget].value = media.id;
            this.element.config[this.currentMediaTarget].source = 'static';
            this.updateElementData(media);

            this.$emit('element-update', this.element);
        },

        // Update element data
        updateElementData(media = null) {
            const mediaId = media === null ? null : media.id;

            if (!this.element.data) {
                this.element.data = {
                    [`${this.currentMediaTarget}Id`]: mediaId,
                    [`${this.currentMediaTarget}`]: media
                };

                return;
            }

            this.element.data[`${this.currentMediaTarget}Id`] = mediaId;
            this.element.data[this.currentMediaTarget] = media;
        },

        // Remove media from modal
        onMediaModalRemove() {
            this.onMediaRemove(this.currentMediaTarget);
        },

        // Toggle media modal
        onCloseModal() {
            this.mediaModalIsOpen = false;
        },

        onOpenMediaModal(target) {
            this.currentMediaTarget = target;
            this.mediaModalIsOpen = true;
        },
    }
});
