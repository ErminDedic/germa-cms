Shopware.Component.register('sw-cms-el-preview-category-card', () => import('./preview'));
Shopware.Component.register('sw-cms-el-config-category-card', () => import('./config'));
Shopware.Component.register('sw-cms-el-category-card', () => import('./component'));

Shopware.Service('cmsService').registerCmsElement({
    name: 'category-card',
    label: 'sw-cms.elements.category-card.label',
    component: 'sw-cms-el-category-card',
    configComponent: 'sw-cms-el-config-category-card',
    previewComponent: 'sw-cms-el-preview-category-card',
    defaultConfig: {
        // Content
        media: {
            source: 'static',
            value: null,
            required: true,
            entity: {
                name: 'media'
            }
        },
        headline: {
            source: 'static',
            value: 'Anhänger',
        },
        text: {
            source: 'static',
            value: 'Elegante Details',
        },
        button: {     
            source: 'static',
            value: {
                url: '',
                text: 'JETZT ENTDECKEN',
                title: '',
                type: 'secondary',
                size: 'md',
                outline: false,
                block: false,
                newTab: false,
            }     
        },

        // Settings
        variant: {
            source: 'static',
            value: 'variant1'
        }
    }
});
