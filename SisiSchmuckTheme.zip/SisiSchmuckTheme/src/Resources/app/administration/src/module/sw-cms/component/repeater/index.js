import template from './repeater.html.twig';
import './repeater.scss';

import RepeaterBlock from './utilities/repeater-block';
import RepeaterDropZone from './utilities/repeater-drop-zone';

const { Component } = Shopware;
const { cloneDeep } = Shopware.Utils.object;

Component.register('repeater', {
    template,

    model: {
        prop: 'fields',
        event: 'update:fields'
    },

    props: ['fields', 'formName', 'defaultValue', 'label', 'blockName', 'addButtonText'],

    components: {
        'repeater-block': RepeaterBlock,
        'repeater-drop-zone': RepeaterDropZone
    },
    
    data () {
        return {
            pFields: this.fields.map(
                el => ({
                    ...el,
                    id: Math.ceil(Math.random() * 1000000000)
                })
            ),
            entered: -1
        }
    },

    methods: {
        setFields (newFields) {
            this.pFields = newFields;
            this.$emit('update:fields', this.pFields);
        },

        // Add new item
        add() {
            // Create a deep copy of the array of fields
            const newFields = cloneDeep(this.pFields);

            // Create a new field object
            const newField = {
                // Generate a unique ID for the new field
                id: Math.ceil(Math.random() * 1000000000),
                // Set the name of the new field
                name: this.formName,
                // Create a deep copy of the default value for the new field
                value: cloneDeep(this.defaultValue)
            };

            // Add the new field to the end of the array
            newFields.push(newField);

            // Update the state or relevant data with the new array of fields
            this.setFields(newFields);
        },

        // Duplicate item
        duplicate(index) {
            // Create a deep copy of the array of fields
            const newFields = cloneDeep(this.pFields);
    
            // Retrieve the field to duplicate
            const fieldToDuplicate = newFields[index];

            // Create a copy of the field
            const duplicatedField = {
                id: Math.ceil(Math.random() * 1000000000),
                name: fieldToDuplicate.name,
                value: cloneDeep(fieldToDuplicate.value)
            };

            // Insert the duplicated field after the original field
            newFields.splice(index + 1, 0, duplicatedField);
            
            // Update the state or relevant data with the new array
            this.setFields(newFields);
        },

        // Remove item
        remove(index) {
            // Create a deep copy of the array of fields
            const newFields = cloneDeep(this.pFields);

            // Remove the field at the specified index
            newFields.splice(index, 1);

            // Update the state or relevant data with the new array of fields
            this.setFields(newFields);
        },

        // Move item up or down
        move(from, to) {
            // Ensure 'from' index is a valid integer, default to 0 if not
            from = parseInt(from, 10) || 0;

            // Create a deep copy of the array of fields
            const newFields = cloneDeep(this.pFields);

            // Remove the element at 'from' index and store it in 'el'
            let el = newFields.splice(from, 1);

            // Insert the removed element at 'to' index
            newFields.splice(to, 0, el[0]);

            // Update the state or relevant data with the new array
            this.setFields(newFields);

            // Reset the 'entered' value
            this.entered = -1;
        }
    }
});