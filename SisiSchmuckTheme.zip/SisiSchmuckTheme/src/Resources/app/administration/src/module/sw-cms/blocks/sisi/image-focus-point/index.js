Shopware.Component.register('sw-cms-preview-image-focus-point', () => import('./preview'));
Shopware.Component.register('sw-cms-block-image-focus-point', () => import('./component'));

Shopware.Service('cmsService').registerCmsBlock({
    name: 'image-focus-point',
    label: 'sw-cms.blocks.sisi.image-focus-point.label',
    category: 'sisi',
    component: 'sw-cms-block-image-focus-point',
    previewComponent: 'sw-cms-preview-image-focus-point',
    defaultConfig: {
        marginTop: '20px',
        marginBottom: '20px',
        marginLeft: '0px',
        marginRight: '0px',
        sizingMode: 'boxed'
    },
    slots: {
        content: {
            type: 'image-focus-point',
        },
    }
});
