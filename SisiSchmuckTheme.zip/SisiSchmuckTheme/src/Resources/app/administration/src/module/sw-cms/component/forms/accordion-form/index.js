import template from './accordion-form.html.twig';

const { Component } = Shopware;

Component.register('accordion-form', {
    template,

    props: {
        value: {
            type: Object,
            required: true
        },

        index: {
            type: Number
        }
    },

    computed: {
        itemValue: {
          get () { return this.value },
          set (itemValue) { this.$emit('input', itemValue) }
        }
    },
});
