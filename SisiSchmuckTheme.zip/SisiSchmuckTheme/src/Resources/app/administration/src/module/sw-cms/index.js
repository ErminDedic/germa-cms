import './sw-cms.scss';

// Mixin
import './mixin/sw-cms-element-media.js';
import './mixin/sw-cms-repeater-item-media.js';

// Component
import './component/sw-cms-link-field';
import './component/sw-cms-config-divider';
import './component/sw-cms-heading-field';
import './component/sw-cms-style-color-field';
import './component/forms';
import './component/repeater';

// Element
import './elements/image-focus-point';
import './elements/title';
import './elements/accordion';
import './elements/timeline';
import './elements/newsletter-minimal';
import './elements/card';
import './elements/materials';
import './elements/image-text-list';
import './elements/product-highlights';
import './elements/product-slider'; // override of product slider
import './elements/product-listing'; // override of product listing
import './elements/icon-card';
import './elements/category-card';
import './elements/reviews';
import './elements/banner-image';
import './elements/sisi-bundles';
import './elements/sisi-video';
import './elements/seo-text';

// Blocks
import './blocks/sisi/image-focus-point';
import './blocks/sisi/title';
import './blocks/sisi/accordion';
import './blocks/sisi/timeline';
import './blocks/sisi/newsletter-minimal';
import './blocks/sisi/three-cards';
import './blocks/sisi/four-materials';
import './blocks/sisi/image-text-list';
import './blocks/sisi/product-highlights';
import './blocks/sisi/four-icon-cards';
import './blocks/sisi/category-cards';
import './blocks/sisi/reviews';
import './blocks/sisi/banner-image';
import './blocks/sisi/sisi-bundles';
import './blocks/sisi/sisi-video';
import './blocks/sisi/image-with-products';
import './blocks/sisi/image-with-product-box';
import './blocks/sisi/image-with-product-box-left';
import './blocks/sisi/image-with-products-left';
