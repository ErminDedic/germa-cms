import template from './sw-cms-el-config.html.twig';

const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element'),
        Mixin.getByName('cms-element-media')
    ],

    data() {
        return {
            // List in repeater default values
            defaultValue: {
                value: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
            }
        }
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('text');
        },
    }
};
