import template from './sw-cms-block.html.twig';
import './sw-cms-block.scss';

export default {
    template,
};
