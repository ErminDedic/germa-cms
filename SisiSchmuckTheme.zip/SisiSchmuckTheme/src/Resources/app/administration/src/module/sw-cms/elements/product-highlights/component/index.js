import template from './sw-cms-el.html.twig';
import './sw-cms-el.scss';
 
const { Mixin } = Shopware;

export default {
    template,

    mixins: [
        Mixin.getByName('cms-element')
    ],

    computed: {
        // Content
        textLeft() {
            return this.element.config.textLeft.value;
        },

        fields() {
            return this.element.config.fields.value;
        },

        media() {
            return this.element.config.media.value;
        },

        previewImage() {
            return this.element.config.previewImage.value;
        },
        
        headline() {
            return this.element.config.headline.value;
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            this.initElementConfig('product-highlights');
            this.initElementData('product-highlights');
        },
    }
};
