import Plugin from 'src/plugin-system/plugin.class';
import DomAccess from 'src/helper/dom-access.helper';

export default class CompleteLookSliderPlugin extends Plugin {
    static options = {
        mainProductBuyInfoSelector: '#mainProductBuyInfo',
        productCheckboxSelector: '.js-complete-look-checkbox'
    };

    init() {
        this.productCheckboxes = DomAccess.querySelectorAll(this.el, this.options.productCheckboxSelector);
        this.mainProductBuyInfo = DomAccess.querySelector(document, this.options.mainProductBuyInfoSelector);

        this._registerEvents();
    }

    _registerEvents() {
        this.productCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', this._handleCheckboxChange.bind(this, checkbox));
        });
    }

    _handleCheckboxChange(checkbox) {
        const productId = checkbox.dataset.productId;
        const hiddenGroupClass = 'hidden-line-items-' + productId;

        if (checkbox.checked) {
            // Create container to group the hidden inputs for easy removal
            const container = document.createElement('div');
            container.classList.add(hiddenGroupClass);

            container.innerHTML = `
                <input type="hidden" name="lineItems[${productId}][id]" value="${productId}">
                <input type="hidden" name="lineItems[${productId}][type]" value="product">
                <input type="hidden" name="lineItems[${productId}][referencedId]" value="${productId}">
                <input type="hidden" name="lineItems[${productId}][stackable]" value="1">
                <input type="hidden" name="lineItems[${productId}][removable]" value="1">
            `;

            this.mainProductBuyInfo.appendChild(container);
        } else {
            // Remove the group of hidden inputs
            const existingContainer = this.mainProductBuyInfo.querySelector(`.${hiddenGroupClass}`);
            if (existingContainer) {
                existingContainer.remove();
            }
        }
    }
}
