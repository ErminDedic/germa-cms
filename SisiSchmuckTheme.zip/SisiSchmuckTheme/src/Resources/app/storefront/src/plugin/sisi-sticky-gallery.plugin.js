const { PluginBaseClass } = window;

export default class SisiStickyGalleryPlugin extends PluginBaseClass {
    init() {
        window.addEventListener('scroll', this.onScroll.bind(this));
        const mediaElement = document.querySelector('.product-detail-media .cms-element-image-gallery');
        if (mediaElement) {
            mediaElement.style.position = 'static';
        }
    }

    onScroll() {
        if (window.innerWidth < 992) {
            return;
        }

        const mediaWrapElement = document.querySelector('.product-detail-media');
        const mediaElement = document.querySelector('.product-detail-media .cms-element-image-gallery');
        if (!mediaElement || !mediaWrapElement) {
            return;
        }

        if (mediaElement.offsetHeight >= mediaWrapElement.offsetHeight)  {
            mediaElement.style.position = 'static';
            return;
        } else {
            mediaElement.style.position = 'absolute';
        }

        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

        const rectWrap = mediaWrapElement.getBoundingClientRect();
        const elementTop = scrollTop + rectWrap.top;
        const scrolledFromElementTop = scrollTop - elementTop;
        let scrollAmount = 0;

        // Calculate how much it is out of screen
        let screenOut = 0;
        if (window.innerHeight < mediaElement.offsetHeight) {
            screenOut = mediaElement.offsetHeight - window.innerHeight;
        }

        // Calculate max top
        let maxTop = mediaWrapElement.offsetHeight - mediaElement.offsetHeight;

        if (scrolledFromElementTop > 0 && scrolledFromElementTop >= screenOut) {
            scrollAmount = scrolledFromElementTop - screenOut;
        }

        if (scrollAmount > maxTop) {
            scrollAmount = maxTop;
        }

        mediaElement.style.top = `${scrollAmount}px`;
    }
}
