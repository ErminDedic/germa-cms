import Plugin from 'src/plugin-system/plugin.class';

export default class Timelinelugin extends Plugin {
    static options = {
        navLinkSelector: '.nav-link',
        progressBarSelector: '.js-progress-bar',
        navHeadlineSelector: '.js-timeline-navigation-headline',
        btnPrevSelector: '.js-btn-prev',
        btnNextSelector: '.js-btn-next'
    };

    init() {
        this.currentIndex = 0;

        this.tabs = this.el.querySelectorAll(this.options.navLinkSelector);
        this.progressBar = this.el.querySelector(this.options.progressBarSelector);

        this.headline = this.el.querySelector(this.options.navHeadlineSelector);
        this.btnPrev = this.el.querySelector(this.options.btnPrevSelector);
        this.btnNext = this.el.querySelector(this.options.btnNextSelector);

        this._registerEvents();

        this.headline.textContent = this.tabs[this.currentIndex].textContent.trim();
        this._updateProgress(); // Initialize progress bar
    }

    _registerEvents() {
        this.tabs.forEach((tab, index) => {
            tab.addEventListener('click', () => {
                this._showTab(index);
            });
        });

        this.btnPrev.addEventListener('click', () => {
            if (this.currentIndex > 0) {
                this._showTab(this.currentIndex - 1);
            }
        });

        this.btnNext.addEventListener('click', () => {
            if (this.currentIndex < this.tabs.length - 1) {
                this._showTab(this.currentIndex + 1);
            }
        });
    }

    _showTab(index) {
        this.tabs[this.currentIndex].classList.remove('active');
        this.el.querySelector(this.tabs[this.currentIndex].dataset.bsTarget).classList.remove('show', 'active');

        this.currentIndex = index;

        this.tabs[this.currentIndex].classList.add('active');
        this.el.querySelector(this.tabs[this.currentIndex].dataset.bsTarget).classList.add('show', 'active');
        this.headline.textContent = this.tabs[this.currentIndex].textContent.trim();

        this._updateProgress(); // Update progress bar on tab change
    }

    _updateProgress() {
        const percentage = (this.currentIndex / (this.tabs.length - 1)) * 94;

        if (this.progressBar) {
            this.progressBar.style.width = `${percentage}%`;
        }
    }
}
