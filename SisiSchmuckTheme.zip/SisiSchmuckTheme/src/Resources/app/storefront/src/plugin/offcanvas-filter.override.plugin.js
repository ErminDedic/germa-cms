import OffCanvas from 'src/plugin/offcanvas/offcanvas.plugin';
import DomAccess from 'src/helper/dom-access.helper';
import OffCanvasFilter from 'src/plugin/offcanvas-filter/offcanvas-filter.plugin';

export default class OffcanvasFilterPlugin extends OffCanvasFilter {
    
    init() {
        super.init();
    }

    /**
     * On clicking the trigger item the OffCanvas shall open and the current
     * filter content should be moved inside the OffCanvas.
     * @param {Event} event
     * @private
     */
    _onClickOffCanvasFilter(event) {
        event.preventDefault();

        const filterContent = document.querySelector('[data-off-canvas-filter-content="true"]');

        if (!filterContent) {
            throw Error('There was no DOM element with the data attribute "data-offcanvas-filter-content".');
        }

        // Changed from bottom to start class
        OffCanvas.open(
            filterContent.innerHTML,
            () => {},
            'start',
            true,
            OffCanvas.REMOVE_OFF_CANVAS_DELAY(),
            true,
            'offcanvas-filter'
        );

        const filterPanel = DomAccess.querySelector(filterContent, '.filter-panel');

        // move filter from original place to offcanvas
        filterPanel.remove();

        window.PluginManager.getPluginInstances('Listing')[0].refreshRegistry();
        document.$emitter.subscribe('onCloseOffcanvas', this._onCloseOffCanvas.bind(this));

        this.$emitter.publish('onClickOffCanvasFilter');
    }
}
