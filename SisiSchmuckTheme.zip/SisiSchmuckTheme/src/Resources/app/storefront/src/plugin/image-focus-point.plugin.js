import Plugin from 'src/plugin-system/plugin.class';

export default class Timelinelugin extends Plugin {
    static options = {
        productHoverContentSelector: '#imageFocusPointProductHoverContent',
        productModalSelector: '#imageFocusPointProductModal',
        dotSelector: '#imageFocusPointDot'
    };

    init() {
        this.productHoverContent = this.el.querySelector(this.options.productHoverContentSelector);
        this.productModal = this.el.querySelector(this.options.productModalSelector);
        this.dot = this.el.querySelector(this.options.dotSelector);

        this._removeContent();
        this._hideContent();
        this._registerEvents();
    }

    _registerEvents() {
        if (this.dot && this.productHoverContent) {
            this.dot.addEventListener('mouseenter', () => this._showContent());
            this.dot.addEventListener('mouseleave', () => this._hideContentOnLeave());
            this.productHoverContent.addEventListener('mouseenter', () => this._showContent());
            this.productHoverContent.addEventListener('mouseleave', () => this._hideContentOnLeave());
        }
    }

    _isDesktop() {
        return window.innerWidth > 992;
    }

    _removeContent() {
        if (this._isDesktop()) {
            if (this.productModal) {
                this.productModal.remove();
            }
        } else {
            if (this.productHoverContent) {
                this.productHoverContent.remove();
            }
        }
    }


    _hideContent() {
        if (this.productHoverContent) {
            this.productHoverContent.style.display = 'none';
        }
    }

    _showContent() {
        if (this.productHoverContent) {
            this.productHoverContent.style.display = 'block';

            setTimeout(() => {
                this._checkOverflow();
            }, 10);
        }
    }

    _hideContentOnLeave() {
        if (!this.dot.matches(':hover') && !this.productHoverContent.matches(':hover')) {
            this._hideContent();
        }
    }

    _checkOverflow() {
        if (!this.productHoverContent) return;

        const dotRect = this.dot.getBoundingClientRect();
        const contentRect = this.productHoverContent.getBoundingClientRect();
        const containerRect = this.el.getBoundingClientRect();

        // Check if content overflows on the right
        if (dotRect.right + contentRect.width > containerRect.right) {
            this.productHoverContent.style.right = '90%';
            this.productHoverContent.style.paddingRight = '28px';
            this.productHoverContent.style.left = '';
            this.productHoverContent.style.paddingLeft = '';
        } else {
            this.productHoverContent.style.left = '90%';
            this.productHoverContent.style.paddingLeft = '28px';
            this.productHoverContent.style.right = '';
            this.productHoverContent.style.paddingRight = '';
        }

        // Check if content overflows on the bottom
        if (dotRect.bottom + contentRect.height > containerRect.bottom) {
            this.productHoverContent.style.bottom = '0%';
            this.productHoverContent.style.top = '';
        } else {
            this.productHoverContent.style.top = '0%';
            this.productHoverContent.style.bottom = '';
        }
    }
}