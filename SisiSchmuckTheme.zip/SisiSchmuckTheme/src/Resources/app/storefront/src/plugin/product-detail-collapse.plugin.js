import Plugin from 'src/plugin-system/plugin.class';
import DomAccess from 'src/helper/dom-access.helper';

export default class ProductDetailCollapsePlugin extends Plugin {

    init() {
        this.collapses = DomAccess.querySelectorAll(this.el, '.collapse');

        this._registerEvents();
    }

    _registerEvents() {
        this.collapses.forEach(collapse => {
            collapse.addEventListener('shown.bs.collapse', () => {
                console.log('nesto')
                const yOffset = -100; // adjust to your header height
                const y = collapse.getBoundingClientRect().top + window.scrollY + yOffset;

                window.scrollTo({ top: y, behavior: 'smooth' });
            });
        });
    }
}
