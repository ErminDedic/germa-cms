import Plugin from 'src/plugin-system/plugin.class';

export default class InViewportPlugin extends Plugin {
    static options = {
        classNameInViewport: 'in-viewport',
        classNameHasAnimation: 'has-animation',
        threshold: 0.7 // How much of the element must be visible (70%)
    };

    init() {
        this.el.classList.add(this.options.classNameHasAnimation);

        this._initObserver();
    }

    _initObserver() {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        this.el.classList.add(this.options.classNameInViewport);
                    } 
                });
            },
            {
                threshold: this.options.threshold
            }
        );

        observer.observe(this.el);
    }
}
