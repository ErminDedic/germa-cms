import Plugin from 'src/plugin-system/plugin.class';

export default class SisiVideoPlugin extends Plugin {

    init() {
        this.video = this.el;

        this.video.addEventListener('click', () => {
            if (this.video.paused) {
                this.video.play();
            } else {
                this.video.pause();
            }
        });
    }
}
