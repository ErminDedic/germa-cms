import Plugin from 'src/plugin-system/plugin.class';

export default class StickyHeaderPlugin extends Plugin {
    init() {

        this.header = this.el;
        this.headerHeight = this.header.offsetHeight;

        this.header.style.top = -this.headerHeight + 'px';

        this._registerEvents();
    }

    _registerEvents() {
        var lastScrollTop = 0;

        document.addEventListener('scroll', () => {
            var st = window.pageYOffset || document.documentElement.scrollTop;

            if (st > this.headerHeight) {
                this.header.classList.add('sticky-active');
                document.body.style.paddingTop = this.headerHeight + 'px';
                this.header.style.top = 0;

                // if (st > lastScrollTop){
                //     // scroll down
                //     this.header.style.top = -this.headerHeight + 'px';
                // } else {
                //     //scroll up
                //     this.header.style.top = 0;
                // }
            }
            else if (st <= 30) {
                this.header.classList.remove('sticky-active');
                this.headerHeight = this.header.offsetHeight;
                this.header.style.top = -this.headerHeight + 'px';
                document.body.style.paddingTop = 0;
            }

            lastScrollTop = st <= 0 ? 0 : st;
        });
    }
}
