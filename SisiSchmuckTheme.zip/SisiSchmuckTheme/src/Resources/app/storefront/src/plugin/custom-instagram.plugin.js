import Plugin from 'src/plugin-system/plugin.class';
import DomAccess from 'src/helper/dom-access.helper';

export default class CustomInstagramPlugin extends Plugin {
    init() {
        this._registerEvents();
        this._checkCookieConsent();
        this._addMetaCdnClass(); 
        this._observeMetaCdnClass(); 
    }

    _registerEvents() {
        this.overlayContainer = DomAccess.querySelector(this.el, '.overlay-container');
        this.showButton = DomAccess.querySelector(this.overlayContainer, 'button');
        this.sliderControls = DomAccess.querySelector(this.el, '.base-slider-controls');
        
        this.instagramDirectElements = this.el.querySelectorAll('.instagram-direct');
        this.instagramDirectElements.forEach((el) => {
            el.style.display = 'none';
        });

        if (this.sliderControls && getComputedStyle(this.overlayContainer).display !== 'none') {
            this.sliderControls.style.pointerEvents = 'none';
        }

        if (this.showButton) {
            this.showButton.addEventListener('click', this._onShowButtonClick.bind(this));
        }
    }

    _checkCookieConsent() {
        const consentValue = this._getCookie('instagram-consent'); 

        if (consentValue === 'accepted') {
            this._enableSlider();  
        }
    }

    _onShowButtonClick() {
        this._setCookie('instagram-consent', 'accepted', 30);

        this._enableSlider();   
        this._loadInstagramLinks();  

        this._addMetaCdnClass(); 
    }

    _enableSlider() {
        if (this.overlayContainer) {
            this.overlayContainer.style.display = 'none';
        }

        if (this.sliderControls) {
            this.sliderControls.style.pointerEvents = 'auto';
        }

        const sliderInner = DomAccess.querySelector(this.el, '.cms-element-solid-ie-feed-slider-inner-container');
        if (sliderInner) {
            sliderInner.style.display = 'block';
        }

        if (this.instagramDirectElements) {
            this.instagramDirectElements.forEach((el) => {
                el.style.display = 'block';
            });
        }
    }

    _getCookie(name) {
        const decodedCookie = decodeURIComponent(document.cookie);
        const cookieArr = decodedCookie.split(';');

        for (let i = 0; i < cookieArr.length; i++) {
            let c = cookieArr[i].trim();
            if (c.indexOf(name + '=') === 0) {
                return c.substring(name.length + 1, c.length);
            }
        }
        return null;
    }
    
    _setCookie(name, value, days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        const expires = 'expires=' + date.toUTCString();
        document.cookie = `${name}=${value};${expires};path=/`;
    }

    _loadInstagramLinks() {
       
    }

    _addMetaCdnClass() {
        const consentValue = this._getCookie('instagram-consent');

        if (consentValue === 'accepted') {
            const feedDiv = document.querySelector('.solid-ie-feed');
            if (feedDiv) {
                feedDiv.classList.add('solid-ie-feed-meta-cdn');
            }
        }
    }

    _observeMetaCdnClass() {
        const targetNode = document.querySelector('.solid-ie-feed');

        if (targetNode) {
            const observer = new MutationObserver((mutationsList) => {
                for (let mutation of mutationsList) {
                    if (mutation.type === 'attributes' && mutation.target.classList.contains('solid-ie-feed-meta-cdn')) {
                        this._reloadCmsElement();  
                    }
                }
            });

            const config = { attributes: true, childList: false, subtree: false };
            observer.observe(targetNode, config);
        }
    }

    _reloadCmsElement() {
        const cmsElement = document.getElementById('solid-ie-feed-container');
        if (cmsElement) {
          
            location.reload(); 
        }
    }
}
