import NavbarPlugin from 'src/plugin/navbar/navbar.plugin';

export default class NavbarPluginOverride extends NavbarPlugin {
    
    init() {
        super.init();
    }

    _toggleNavbar(topLevelLink, event) {
        const currentDropdown = window.bootstrap.Dropdown.getOrCreateInstance(topLevelLink);
        if (event.type === 'mouseenter') {
            this._isMouseOver = true;
            this._debounce(() => {
                this._closeAllDropdowns();

                if (this._isMouseOver && currentDropdown?._menu && !currentDropdown._menu.classList.contains('show')) {
                    currentDropdown.show();
                    this.$emitter.publish('showDropdown');
                }
            }, this.options.debounceTime);
        } else if (event.type === 'mouseleave') {
            this._isMouseOver = false;
        }
    }
}
