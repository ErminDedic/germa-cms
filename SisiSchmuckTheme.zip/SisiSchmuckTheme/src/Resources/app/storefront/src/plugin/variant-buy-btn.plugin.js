import Plugin from 'src/plugin-system/plugin.class';

export default class StickyHeaderPlugin extends Plugin {
    init() {
        this.variantBtn = this.el;

        const storedParentId = localStorage.getItem('parentId');
        const currentParentId = this.options.parentId;

        if (!storedParentId || storedParentId !== currentParentId) {
            this.variantBtn.classList.remove('d-none');
        }

        this._registerEvents();
        this._bindCombinableOptions();
    }

    _registerEvents() {
        this.variantBtn.addEventListener('click', () => {
            this.variantBtn.classList.add('d-none');

            const currentParentId = this.options.parentId;
            if (currentParentId) {
                localStorage.setItem('parentId', currentParentId);
            }

            const target = document.getElementById('variant-configurator');
            if (target) {
                const yOffset = -100; // 100px offset from top
                const y = target.getBoundingClientRect().top + window.pageYOffset + yOffset;

                window.scrollTo({
                    top: y,
                    behavior: 'smooth',
                });
            }
        });
    }

    _bindCombinableOptions() {
        const optionLabels = document.querySelectorAll('.product-detail-configurator-option-label.is-combinable');

        optionLabels.forEach(label => {
            label.addEventListener('click', () => {
                if (this.options.parentId) {
                    localStorage.setItem('parentId', this.options.parentId);
                }
            });
        });
    }
}
