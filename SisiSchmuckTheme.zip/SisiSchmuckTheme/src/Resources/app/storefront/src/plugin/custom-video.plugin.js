import Plugin from 'src/plugin-system/plugin.class';
import DomAccess from 'src/helper/dom-access.helper';
import DeviceDetection from 'src/helper/device-detection.helper';

export default class CustomVideoPlugin extends Plugin {
    static options = {
        videoSelector: 'video',
        previewContentSelector: '.js-preview-content'
    };

    static activeInstance = null;

    init() {
        this.video = DomAccess.querySelector(this.el, this.options.videoSelector);
        this.previewContent = DomAccess.querySelector(this.el, this.options.previewContentSelector);
        this.originalContainer = this.video.parentElement;

        const videoSource = this.video.getAttribute('data-src');
        this.video.setAttribute('src', videoSource);
        this.video.setAttribute('playsinline', 'true');

        this.isAnimating = false; // Flag for our animation loop
        this.registerEvents();
    }

    registerEvents() {
        const submitEvent = DeviceDetection.isTouchDevice() ? 'touchstart' : 'click';
        this.previewContent.addEventListener(submitEvent, this.openModal.bind(this));

        this.video.addEventListener('ended', this.endedVideo.bind(this));
        this.video.addEventListener('pause', this.stopProgressAnimation.bind(this));
    }

    openModal() {
        if (CustomVideoPlugin.activeInstance && CustomVideoPlugin.activeInstance !== this) {
            CustomVideoPlugin.activeInstance.closeModal();
        }
        CustomVideoPlugin.activeInstance = this;
    
        let modal = document.querySelector('.video-modal');
        if (!modal) {
            modal = document.createElement('div');
            modal.classList.add('video-modal');
            modal.innerHTML = `
                <div class="video-modal-content">
                    <div class="video-modal-progress">
                        <div class="video-modal-progress-bar"></div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
    
            modal.addEventListener('click', (event) => {
                if (event.target === modal) {
                    this.closeModal();
                }
            });
            modal.querySelector('.video-modal-content').addEventListener('click', (event) => {
                event.stopPropagation();
            });
        }
    
        // Clear previous content to avoid duplicates
        const modalContent = modal.querySelector('.video-modal-content');
        while (modalContent.firstChild) {
            modalContent.removeChild(modalContent.firstChild);
        }
    
        // Re-add the progress bar
        const progressContainer = document.createElement('div');
        progressContainer.classList.add('video-modal-progress');
        const progressBar = document.createElement('div');
        progressBar.classList.add('video-modal-progress-bar');
        progressContainer.appendChild(progressBar);
        modalContent.appendChild(progressContainer);
    
        // Ensure video source is set
        const videoSource = this.video.getAttribute('data-src');
        if (!this.video.getAttribute('src')) {
            this.video.setAttribute('src', videoSource);
        }
    
        // Move video into modal
        modalContent.appendChild(this.video);
        modal.classList.add('open');
        this.video.play();
    
        // Start animating the progress
        this.startProgressAnimation();
    }
    

    closeModal() {
        const modal = document.querySelector('.video-modal');
        if (modal) {
            // Move video back to original container before removing modal
            if (this.originalContainer) {
                this.originalContainer.appendChild(this.video);
            }
    
            // Pause and reset video
            this.video.pause();
            this.video.currentTime = 0;
    
            // Remove modal from DOM
            modal.remove();
        }
    
        // Reset active instance
        if (CustomVideoPlugin.activeInstance === this) {
            CustomVideoPlugin.activeInstance = null;
        }
    
        // Stop progress animation
        this.stopProgressAnimation();
    }
    
    

    endedVideo() {
        this.closeModal();
    }

    /**
     * Start requestAnimationFrame-based progress updates
     */
    startProgressAnimation() {
        this.isAnimating = true;
        this.animateProgress();
    }

    /**
     * Stop requestAnimationFrame-based progress updates
     */
    stopProgressAnimation() {
        this.isAnimating = false;
    }

    /**
     * Continuously update the progress bar while video is playing
     */
    animateProgress() {
        if (!this.isAnimating || !this.video || this.video.paused || this.video.ended) {
            return;
        }

        const progressBar = document.querySelector('.video-modal-progress-bar');
        if (!progressBar || !this.video.duration) {
            return;
        }

        const currentTime = this.video.currentTime;
        const duration = this.video.duration;
        const progressPercent = (currentTime / duration) * 100;

        progressBar.style.width = `${progressPercent}%`;

        // Keep requesting frames
        requestAnimationFrame(this.animateProgress.bind(this));
    }
}
