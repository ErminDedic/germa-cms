import DomAccess from 'src/helper/dom-access.helper';
import OffcanvasMenuPlugin from 'src/plugin/main-menu/offcanvas-menu.plugin';

export default class OffcanvasMenuRootFirstOpen extends OffcanvasMenuPlugin {
    _getLinkEventHandler(event, link) {
        // First open (no link clicked)
        if (!link) {
            const initialContentElement = DomAccess.querySelector(document, this.options.initialContentSelector);
            this._content = initialContentElement.innerHTML;

            console.log(window.rootNavigationId);
            const rootId = window.rootNavigationId || window.activeNavigationId;
            const url = `${this.options.navigationUrl}?navigationId=${rootId}`;

            return this._fetchMenu(url, (htmlResponse) => {
                const navigationContainer = DomAccess.querySelector(initialContentElement, this.options.menuSelector);
                navigationContainer.innerHTML = htmlResponse;
                this._content = initialContentElement.innerHTML;
                return this._openMenu(event);
            });
        }

        // All other clicks: default behavior
        return super._getLinkEventHandler(event, link);
    }
}