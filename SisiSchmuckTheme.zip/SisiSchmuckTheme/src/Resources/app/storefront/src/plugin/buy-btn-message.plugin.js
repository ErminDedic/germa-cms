import Plugin from 'src/plugin-system/plugin.class';

export default class BuyBtnMessagePlugin extends Plugin {
    init() {
        this.buyBtn = this.el;

        this._registerEvents();
    }

    _registerEvents() {
        this.buyBtn.addEventListener('click', () => {
            // Reset animation
            this.buyBtn.classList.remove('animate');
            void this.buyBtn.offsetWidth; // force reflow to restart animation

            // Add animate class
            this.buyBtn.classList.add('animate');

            // Clean up after animation to allow retriggering
            setTimeout(() => {
                this.buyBtn.classList.remove('animate');
            }, 2500); // adjust based on total animation duration
        });
    }
}
