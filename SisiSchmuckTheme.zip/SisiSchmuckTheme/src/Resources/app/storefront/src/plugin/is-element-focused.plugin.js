import Plugin from 'src/plugin-system/plugin.class';

export default class IsElementFocusedPlugin extends Plugin {
    init() {
        // Assign initial class
        this.el.classList.add('is-not--focused');

        this._registerEvents();
    }

    _registerEvents() {
        const checkIfInVerticalCenter = () => {
            const rect = this.el.getBoundingClientRect();
            const viewportCenterY = window.innerHeight / 2;

            // Check if element overlaps the vertical center line
            const touchesCenter = rect.top <= viewportCenterY && rect.bottom >= viewportCenterY;

            if (touchesCenter) {
                this.el.classList.remove('is-not--focused');
                this.el.classList.add('is--focused');
            } else {
                this.el.classList.remove('is--focused');
                this.el.classList.add('is-not--focused');
            }
        };

        // Run on scroll + resize
        window.addEventListener('scroll', checkIfInVerticalCenter, { passive: true });
        window.addEventListener('resize', checkIfInVerticalCenter);

        // Initial check
        checkIfInVerticalCenter();
    }
}
