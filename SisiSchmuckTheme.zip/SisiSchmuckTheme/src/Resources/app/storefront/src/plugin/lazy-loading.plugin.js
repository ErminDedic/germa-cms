export default class SisiLazyLoading {
    /**
     * Prepares the lazy load
     */
    constructor() {
        this.registerEvents();
    }

    /**
     * Registers some custom events
     */
    registerEvents() {
        const me = this;

        document.addEventListener('lazyloaded', function (e) {
            setTimeout(() => {
                e.target.classList.add('lazyloaded-success');
            }, 5)

            me._updateImageZoom(e.target);
            me._updateSliders(e.target)
        });
    }

    _updateSliders(elem) {
        const classList = elem.classList;

        if (!classList.contains('image-slider-image') && !classList.contains('gallery-slider-thumbnails-image')) {
            return;
        }

        const sliders = [
            { plugin: 'ProductSlider', selector: '[data-product-slide]' },
            { plugin: 'BaseSlider', selector: '[data-base-slider]' },
            { plugin: 'GallerySlider', selector: '[data-gallery-slider]' },
        ];

        sliders.forEach((slider) => {
            this._updateSingleSlider(elem, slider.plugin, slider.selector)
        })
    }

    _updateSingleSlider(elem, pluginName, pluginCssSelector) {
        if (!this._isFunction(elem.closest)) {
            return;
        }

        const pluginContainer = elem.closest(pluginCssSelector);
        if (!pluginContainer) {
            return;
        }

        const sliderPlugin = this._getPluginInstanceFromElement(pluginContainer, pluginName);
        if (sliderPlugin) {
            this._refreshSlider(sliderPlugin._slider);
            this._refreshSlider(sliderPlugin._thumbnailSlider);
        }
    }

    _isFunction(func) {
        return (typeof func === 'function');
    }

    _refreshSlider(tinySlider) {
        if (tinySlider && this._isFunction(tinySlider.refresh)) {
            tinySlider.refresh();
        }
    }

    _updateImageZoom(elem) {
        if (!elem.classList.contains('js-image-zoom-element')) {
            return;
        }

        const instance = this._getPluginInstanceFromElement(elem, 'ImageZoom');

        if (instance) {
            instance.init();
            instance.update();
        }
    }

    _getPluginInstanceFromElement(elem, pluginName) {
        return window.PluginManager.getPluginInstanceFromElement(elem, pluginName);
    }
}
