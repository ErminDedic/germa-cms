import Plugin from 'src/plugin-system/plugin.class';

export default class SearchOnListingPlugin extends Plugin {
    init() {
        if (document.querySelector('.cms-element-product-listing')) {
            this._showSearchCollapse();
        }
    }

    _showSearchCollapse() {
        const header = document.querySelector('.header-main');
        if (!header) return;

        const collapseElements = header.querySelectorAll('#searchCollapse');

        collapseElements.forEach(el => {
            new bootstrap.Collapse(el, { toggle: false }).show();
        });
    }
}
