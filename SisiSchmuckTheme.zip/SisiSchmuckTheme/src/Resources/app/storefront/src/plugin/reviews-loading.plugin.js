import Plugin from 'src/plugin-system/plugin.class';

export default class ReviewsWithBtnLoadingPlugin extends Plugin {

    static options = {
        loadMoreButtonSelector: '.js-load-more-reviews',
        reviewsSortbySelector: '#reviewsSortby',
        reviewContainerSelector: '.js-review-container',
        pageDataAttribute: 'data-page',
        limitDataAttribute: 'data-limit',
        urlDataAttribute: 'data-url'
    };

    init() {
        this._loadMoreButton = this.el.querySelector(this.options.loadMoreButtonSelector);
        this._reviewList = this.el;
        this._reviewsSortby = this.el.querySelector(this.options.reviewsSortbySelector);

        if (!this._loadMoreButton || !this._reviewList) {
            console.warn('ReviewLoadMorePlugin: Required elements not found.');
            return;
        }

        this._currentPage = parseInt(this._loadMoreButton.dataset.page) || 1;
        this._limit = parseInt(this._loadMoreButton.dataset.limit);

        // Prevent multiple bindings
        if (this._loadMoreButton.dataset.bound === 'true') return;
        this._loadMoreButton.dataset.bound = 'true';

        // Set count of products 
        const currentCountElement = this._loadMoreButton.querySelector('.js-current-count');
        if (currentCountElement) {
            currentCountElement.textContent = this._reviewList.querySelectorAll('.product-detail-review-list-content').length;
        }

        this._registerEvents();
    }

    _registerEvents() {
        // Update the page number and trigger a new fetch when sorting changes
        this._reviewsSortby.addEventListener('change', () => {
            this._currentPage = 1; // Reset to the first page when sorting changes
            this._loadMoreButton.dataset.page = this._currentPage;

            this._onLoadMoreClick();
        });
    
        this._loadMoreButton.addEventListener('click', () => {
            this._currentPage++;
            this._loadMoreButton.dataset.page = this._currentPage;
            this._onLoadMoreClick();
        });

        document.addEventListener('DOMContentLoaded', function () {
            initReviewLoadMore();

            // Observe changes to the review container and re-bind
            const container = document.querySelector('.js-review-container');
            if (!container) return;

            const observer = new MutationObserver(() => {
                initReviewLoadMore();
            });

            observer.observe(container, {
                childList: true,
                subtree: true
            });
        });
    }

    _onLoadMoreClick() {
        const url = new URL(this._loadMoreButton.dataset.url, window.location.origin);
        url.searchParams.set('p', this._currentPage);
        url.searchParams.set('limit', this._limit);

        // Add the current sorting parameter to the request
        const selectedSortValue = this._reviewsSortby.value;
        url.searchParams.set('sort', selectedSortValue);

        fetch(url.toString(), {
            headers: {
                'x-requested-with': 'XMLHttpRequest'
            }
        })
        .then(res => res.text())
        .then(html => {
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = html;

            const newReviews = tempDiv.querySelectorAll('.product-detail-review-list-content');

            if (newReviews.length > 0) {
                const allExistingReviews = this._reviewList.querySelectorAll('.product-detail-review-list-content');
                const lastReview = allExistingReviews[allExistingReviews.length - 1];
    
                newReviews.forEach(r => {
                    if (lastReview && lastReview.parentNode) {
                        lastReview.parentNode.insertBefore(r, lastReview.nextSibling);
                    } else {
                        this._reviewList.appendChild(r); // Fallback
                    }
                });
    
                const currentCountElement = this._loadMoreButton.querySelector('.js-current-count');
                if (currentCountElement) {
                    const currentCount = parseInt(currentCountElement.textContent);
                    currentCountElement.textContent = currentCount + newReviews.length;
                }
            }

            // If fewer reviews are loaded than the limit, hide the "Load More" button
            if (newReviews.length < this._limit) {
                this._loadMoreButton.style.display = 'none';
            }
        });
    }
}
