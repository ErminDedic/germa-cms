import Plugin from 'src/plugin-system/plugin.class';

export default class CustomSelectPlugin extends Plugin {

    static options = {
        nativeSelectSelector: 'select',
        customSelectButtonSelector: 'button',
        customSelectContentSelector: ':scope > div'
    };

    init() {
        this._nativeSelect = this.el.querySelector(this.options.nativeSelectSelector);
        this._customSelectButton = this.el.querySelector(this.options.customSelectButtonSelector);
        this._customSelectContent = this.el.querySelector(this.options.customSelectContentSelector);

        if (!this._nativeSelect || !this._customSelectButton || !this._customSelectContent) {
            console.warn('CustomSelectPlugin: Required elements not found.');
            return;
        }

        this._registerEvents();
    }

    _registerEvents() {
        this._customSelectButton.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();  // Prevents the click event from bubbling up to the document
            this._customSelectContent.classList.toggle('open');
        });

        this._customSelectContent.querySelectorAll('li').forEach(item => {
            item.addEventListener('click', () => {
                const value = item.getAttribute('data-value');
                const label = item.querySelector('span').textContent;

                this._customSelectButton.textContent = label;
                this._nativeSelect.value = value;

                this._customSelectContent.querySelectorAll('li').forEach(i => i.classList.remove('active'));
                item.classList.add('active');

                // Dispatch event on native select
                this._nativeSelect.dispatchEvent(new Event('change', { bubbles: true }));

                // Close the dropdown
                this._customSelectContent.classList.remove('open');
            });
        });

        // Close dropdown when clicking outside the custom select
        document.addEventListener('click', (event) => {
            if (!this.el.contains(event.target)) {
                this._customSelectContent.classList.remove('open');
            }
        });
    }
}
