import SisiLazyLoading from './plugin/lazy-loading.plugin';
import TimelinePlugin from './plugin/timeline.plugin';
import CustomVideoPlugin from './plugin/custom-video.plugin';
import SisiVideoPlugin from './plugin/sisi-video.plugin';
import ImageFocusPointPlugin from './plugin/image-focus-point.plugin';
import CompleteLookSliderPlugin from './plugin/complete-look-slider.plugin';
import CustomInstagramPlugin from './plugin/custom-instagram.plugin';
import CustomSelectPlugin from './plugin/custom-select.plugin';
import ReviewsWithBtnLoadingPlugin from './plugin/reviews-loading.plugin';
import SisiStickyGalleryPlugin from './plugin/sisi-sticky-gallery.plugin';
import InViewportPlugin from './plugin/mobile-animation.plugin';
import StickyHeaderPlugin from './plugin/sticky-header.plugin';
import VariantBuyBtnPlugin from './plugin/variant-buy-btn.plugin';
import SearchOnListingPlugin from './plugin/search-on-listing.plugin';
import BuyBtnMessagePlugin from './plugin/buy-btn-message.plugin';
import ProductDetailCollapsePlugin from './plugin/product-detail-collapse.plugin';
import IsElementFocusedPlugin from './plugin/is-element-focused.plugin';

new SisiLazyLoading();

PluginManager.register('Timeline', TimelinePlugin, '[data-timeline]');
PluginManager.register('CustomVideo', CustomVideoPlugin, '[data-custom-video]');
PluginManager.register('SisiVideo', SisiVideoPlugin, '[data-sisi-video]');
PluginManager.register('ImageFocusPoint', ImageFocusPointPlugin, '[data-image-focus-point]');
PluginManager.register('CompleteLookSlider', CompleteLookSliderPlugin, '[data-complete-look-slider]');
PluginManager.register('CustomInstagram', CustomInstagramPlugin, '[data-custom-instagram]');
PluginManager.register('CustomSelect', CustomSelectPlugin, '[data-custom-select]');
PluginManager.register('ReviewsWithBtnLoading', ReviewsWithBtnLoadingPlugin, '[data-reviews-with-btn-loading]');
PluginManager.register('SisiStickyGalleryPlugin', SisiStickyGalleryPlugin);
PluginManager.register('InViewportPlugin', InViewportPlugin, '[data-in-viewport-plugin]');
PluginManager.register('StickyHeader', StickyHeaderPlugin, '[data-sticky-header]');
PluginManager.register('VariantBuyBtn', VariantBuyBtnPlugin, '[data-variant-buy-btn]');
PluginManager.register('SearchOnListingPlugin', SearchOnListingPlugin);
PluginManager.register('BuyBtnMessagePlugin', BuyBtnMessagePlugin, '[data-buy-btn-message]');
PluginManager.register('ProductDetailCollapsePlugin', ProductDetailCollapsePlugin, '[data-product-detail-collase]');
PluginManager.register('IsElementFocused', IsElementFocusedPlugin, '[data-is-element-focused]');

// Override
PluginManager.override('OffCanvasFilter', () => import('./plugin/offcanvas-filter.override.plugin'), '[data-off-canvas-filter]');
PluginManager.override('Navbar', () => import('./plugin/navbar.override.plugin'), '[data-navbar]');
PluginManager.override('OffCanvasMenu', () => import('./plugin/offcanvas-menu-root.override.plugin'), '[data-off-canvas-menu]');
