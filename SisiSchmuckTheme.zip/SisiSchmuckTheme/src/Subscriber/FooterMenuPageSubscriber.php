<?php

declare(strict_types=1);

namespace SisiSchmuckTheme\Subscriber;

use Shopware\Core\Content\Category\Event\NavigationLoadedEvent;
use Shopware\Core\Content\Category\Service\NavigationLoaderInterface;
use Shopware\Core\Framework\Struct\ArrayStruct;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Storefront\Page\GenericPageLoadedEvent;
use Shopware\Storefront\Pagelet\Header\HeaderPageletLoadedEvent;
use Shopware\Storefront\Pagelet\Header\HeaderPageletLoaderInterface;
use Shopware\Storefront\Pagelet\Menu\Offcanvas\MenuOffcanvasPageletLoadedEvent;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class FooterMenuPageSubscriber implements EventSubscriberInterface
{
    // private HeaderPageletLoaderInterface $navigationLoader;

    public function __construct(
        private readonly NavigationLoaderInterface $navigationLoader
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            HeaderPageletLoadedEvent::class => 'onOffcanvasMenuLoaded',
        ];
    }

    public function onOffcanvasMenuLoaded(HeaderPageletLoadedEvent $event): void
    {
        $context = $event->getSalesChannelContext();
        $serviceId = $context->getSalesChannel()->getServiceCategoryId();

        if ($serviceId) {
            $serviceFooter = $this->navigationLoader->load($serviceId, $context, $serviceId, 1);
            $event->getPagelet()->getNavigation()->setExtensions([
                'service_footer' => $serviceFooter,
            ]);
        }
    }
}
