<?php

namespace SisiSchmuckTheme\Subscriber;

use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Content\Product\Events\ProductListingCriteriaEvent;
use Shopware\Core\Content\Product\Events\ProductListingResultEvent;
use Shopware\Core\Content\Product\Events\ProductSearchCriteriaEvent;
use Shopware\Core\Content\Product\Events\ProductSearchResultEvent;
use Shopware\Core\Content\Product\Events\ProductSuggestCriteriaEvent;
use Shopware\Core\Content\Product\Events\ProductSuggestResultEvent;
use Shopware\Core\Framework\Struct\ArrayStruct;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class ProductBoxSubscriber implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            ProductListingCriteriaEvent::class => 'onProductListingCriteria',
            ProductListingResultEvent::class => 'onProductListingResult',
            ProductSearchCriteriaEvent::class => 'onProductListingCriteria',
            ProductSearchResultEvent::class => 'onProductListingResult',
            ProductSuggestCriteriaEvent::class => 'onProductListingCriteria',
            ProductSuggestResultEvent::class => 'onProductListingResult',
        ];
    }

    public function onProductListingCriteria(ProductListingCriteriaEvent $event): void
    {
        $criteria = $event->getCriteria();
        $this->addAssociations($criteria);
    }

    public function onProductListingResult(ProductListingResultEvent $event): void
    {
        $this->addAdditionalExtension($event);
    }

    private function addAssociations($criteria): void
    {
        // Add associations for both listing and slider
        $criteria->addAssociation('media.media');
        $criteria->addAssociation('properties.group'); // Important for Material properties
    }

    private function addAdditionalExtension($event): void
    {
        $result = $event->getResult();

        foreach ($result->getEntities() as $product) {
            /** @var ProductEntity $product */
            $media = $product->getMedia();

            // Second media
            if ($media && $media->count() > 1) {
                foreach ($media as $mediaEl) {
                    if ($mediaEl->getPosition() === 1) {
                        $product->addExtension('secondMedia', $mediaEl->getMedia());
                        break;
                    }
                }
            }

            // Product materials
            $properties = $product->getProperties();
            if ($properties) {
                $materialValues = [];
                foreach ($properties as $property) {
                    $group = $property->getGroup();
                    if ($group && $group->getName() === 'Material') {
                        $materialValues[] = $property->getName();
                    }
                }

                if (!empty($materialValues)) {
                    $product->addExtension('productMaterial', new ArrayStruct([
                        'materials' => implode(', ', $materialValues),
                    ]));
                }
            }
        }
    }
}
