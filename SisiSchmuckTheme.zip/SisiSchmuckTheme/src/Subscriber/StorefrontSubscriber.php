<?php

declare(strict_types=1);

namespace SisiSchmuckTheme\Subscriber;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Shopware\Storefront\Page\Product\ProductPageLoadedEvent;
use Shopware\Core\System\SalesChannel\Entity\SalesChannelRepository;
use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Framework\Struct\ArrayStruct;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;

class StorefrontSubscriber implements EventSubscriberInterface
{
    public function __construct(
        protected readonly SalesChannelRepository $productRepository
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            ProductPageLoadedEvent::class => 'onProductPageLoaded',
        ];
    }

    public function onProductPageLoaded(ProductPageLoadedEvent $event): void
    {
        $salesChannelContext = $event->getSalesChannelContext();

        // TODO: Fix
        // Get cross-selling products
        // $crossSellings = $event->getPage()->getCrossSellings();
        // if (!$crossSellings) {
            return;
        // }

        foreach ($crossSellings->getElements() as $element) {
            foreach ($element->getProducts()->getElements() as $product) {
                if (!$product instanceof ProductEntity) {
                    continue;
                }

                $productId = $product->getId();
                $criteria = new Criteria([$productId]);
                $criteria->addAssociation('media');
                $criteria->addAssociation('properties.group');

                $productData = $this->productRepository->search($criteria, $salesChannelContext)->first();
                if (!$productData) {
                    continue;
                }

                // Get the second media item
                $media = $productData->getMedia();
                if ($media && $media->count() > 1) {
                    $mediaArray = array_values(iterator_to_array($media->getIterator()));

                    if (isset($mediaArray[1])) {
                        $secondImage = $mediaArray[1];
                        $product->addExtension('secondMedia', $secondImage);
                    }
                }

                // Get product materials
                $properties = $productData->getProperties();
                if ($properties) {
                    $materialValues = [];
                    foreach ($properties as $property) {
                        $group = $property->getGroup();
                        if ($group && $group->getName() === 'Material') {
                            $materialValues[] = $property->getName();
                        }
                    }

                    if (!empty($materialValues)) {
                        $product->addExtension('productMaterial', new ArrayStruct([
                            'materials' => implode(', ', $materialValues),
                        ]));
                    }
                }
            }
        }
    }
}
