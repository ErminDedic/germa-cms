<?php

declare(strict_types=1);

namespace SisiSchmuckTheme\Core\Content\Product\Cms;

use Shopware\Core\Content\Cms\Aggregate\CmsSlot\CmsSlotEntity;
use Shopware\Core\Content\Cms\DataResolver\Element\ElementDataCollection;
use Shopware\Core\Content\Cms\DataResolver\ResolverContext\ResolverContext;
use Shopware\Core\Content\Product\Cms\ProductBoxCmsElementResolver as BaseProductBoxCmsElementResolver;
use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\System\SalesChannel\Entity\SalesChannelRepository;
use Shopware\Core\Framework\Struct\ArrayStruct;
use Shopware\Core\Content\Cms\DataResolver\CriteriaCollection;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Shopware\Core\Content\Cms\DataResolver\Element\AbstractCmsElementResolver;
use Shopware\Core\Content\Cms\DataResolver\Element\CmsElementResolverInterface;
use Shopware\Core\Content\Cms\SalesChannel\Struct\ProductBoxStruct;

class ProductBoxCmsElementResolver extends AbstractCmsElementResolver
{
    public function __construct(
        protected readonly CmsElementResolverInterface $parent,
        protected readonly SalesChannelRepository $productRepository
    ) {
        //
    }

    public function getType(): string
    {
        return $this->parent->getType();
    }

    public function collect(CmsSlotEntity $slot, ResolverContext $resolverContext): ?CriteriaCollection
    {
        return $this->parent->collect($slot, $resolverContext);
    }

    public function enrich(CmsSlotEntity $slot, ResolverContext $resolverContext, ElementDataCollection $result): void
    {
        $this->parent->enrich($slot, $resolverContext, $result);

        /** @var ProductBoxStruct $productBox */
        $productBox = $slot->getData();
        if (!$productBox instanceof ProductBoxStruct) {
            return;
        }

        $product = $productBox->getProduct();

        $salesChannelContext = $resolverContext->getSalesChannelContext();

        if ($product) {
            $productId = $product->getId();

            // Fetch product with media & properties
            $criteria = new Criteria([$productId]);
            $criteria->addAssociation('media');
            $criteria->addAssociation('properties.group');

            $productData = $this->productRepository->search($criteria, $salesChannelContext)->first();

            if ($productData) {
                // Add second media image
                $media = $productData->getMedia();
                if ($media && $media->count() > 1) {
                    $mediaArray = array_values(iterator_to_array($media->getIterator()));

                    if (isset($mediaArray[1])) {
                        $secondImage = $mediaArray[1];
                        $product->addExtension('secondMedia', $secondImage);
                    }
                }

                // Add product materials
                $properties = $productData->getProperties();
                if ($properties) {
                    $materialValues = [];
                    foreach ($properties as $property) {
                        $group = $property->getGroup();
                        if ($group && $group->getName() === 'Material') {
                            $materialValues[] = $property->getName();
                        }
                    }

                    if (!empty($materialValues)) {
                        $product->addExtension('productMaterial', new ArrayStruct([
                            'materials' => implode(', ', $materialValues),
                        ]));
                    }
                }
            }
        }
    }
}
