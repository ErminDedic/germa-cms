<?php

namespace SisiSchmuckTheme\Core\Content\Product\Cms;

use Shopware\Core\Content\Cms\Aggregate\CmsSlot\CmsSlotEntity;
use Shopware\Core\Content\Cms\DataResolver\CriteriaCollection;
use Shopware\Core\Content\Cms\DataResolver\Element\AbstractCmsElementResolver;
use Shopware\Core\Content\Cms\DataResolver\Element\CmsElementResolverInterface;
use Shopware\Core\Content\Cms\DataResolver\Element\ElementDataCollection;
use Shopware\Core\Content\Cms\DataResolver\ResolverContext\ResolverContext;
use Shopware\Core\Content\Cms\SalesChannel\Struct\ProductSliderStruct;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Shopware\Core\System\SalesChannel\Entity\SalesChannelRepository;
use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Core\Framework\Struct\ArrayStruct;

class ProductSliderCmsElementResolver extends AbstractCmsElementResolver
{
    public function __construct(
        protected readonly CmsElementResolverInterface $parent,
        protected readonly SalesChannelRepository $productRepository
    ) {
        //
    }

    public function getType(): string
    {
        return $this->parent->getType();
    }

    public function collect(CmsSlotEntity $slot, ResolverContext $resolverContext): ?CriteriaCollection
    {
        return $this->parent->collect($slot, $resolverContext);
    }

    public function enrich(CmsSlotEntity $slot, ResolverContext $resolverContext, ElementDataCollection $result): void
    {
        $this->parent->enrich($slot, $resolverContext, $result);

        /** @var ProductSliderStruct $slider */
        $slider = $slot->getData();
        if (!$slider instanceof ProductSliderStruct) {
            return;
        }

        $products = $slider->getProducts();
        if (!$products || !$products->count()) {
            return;
        }

        $items = $products->getElements();

        $salesChannelContext = $resolverContext->getSalesChannelContext();

        foreach ($items as $product) {
            if ($product instanceof ProductEntity) {
                $productId = $product->getId();
                $criteria = new Criteria([$productId]);
                $criteria->addAssociation('media');
                $criteria->addAssociation('properties.group');
                $productData = $this->productRepository->search($criteria, $salesChannelContext)->first();

                if ($productData) {
                    $media = $productData->getMedia();
                    if ($media && $media->count() > 1) {
                        $mediaArray = array_values(iterator_to_array($media->getIterator()));

                        if (isset($mediaArray[1])) {
                            $secondImage = $mediaArray[1];
                            $product->addExtension('secondMedia', $secondImage);
                        }
                    }

                    // Product materials
                    $properties = $productData->getProperties();
                    if ($properties) {
                        $materialValues = [];
                        foreach ($properties as $property) {
                            $group = $property->getGroup();
                            if ($group && $group->getName() === 'Material') {
                                $materialValues[] = $property->getName();
                            }
                        }

                        if (!empty($materialValues)) {
                            $product->addExtension('productMaterial', new ArrayStruct([
                                'materials' => implode(', ', $materialValues),
                            ]));
                        }
                    }
                }
            }
        }
    }
}
