<?php

declare(strict_types=1);

namespace SisiSchmuckTheme\Core\Content\Product\Cms;

use Shopware\Core\Content\Product\Cms\ProductBoxCmsElementResolver;

class ImageFocusPointResolver extends ProductBoxCmsElementResolver
{
    public function getType(): string
    {
        return 'image-focus-point';
    }
}
