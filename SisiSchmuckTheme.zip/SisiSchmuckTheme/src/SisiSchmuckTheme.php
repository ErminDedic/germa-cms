<?php

declare(strict_types=1);

namespace SisiSchmuckTheme;

use Shopware\Core\Framework\Plugin;
use Shopware\Storefront\Framework\ThemeInterface;

class SisiSchmuckTheme extends Plugin implements ThemeInterface
{
    // Comment
}
