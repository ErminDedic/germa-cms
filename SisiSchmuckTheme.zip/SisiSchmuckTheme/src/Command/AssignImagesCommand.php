<?php

declare(strict_types=1);

namespace SisiSchmuckTheme\Command;

use Shopware\Core\Content\Media\Aggregate\MediaFolder\MediaFolderEntity;
use Shopware\Core\Content\Media\File\FileSaver;
use Shopware\Core\Content\Media\File\MediaFile;
use Shopware\Core\Content\Media\MediaEntity;
use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Uuid\Uuid;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\Finder\Finder;
use Symfony\Component\Console\Attribute\AsCommand;

#[AsCommand(
    name: "sisi:image:assign-from-folder",
    description: "Scans a folder for product images and assigns them based on folder and file names."
)]
class AssignImagesCommand extends Command
{
    protected static $defaultName = 'sisi:image:assign-from-folder';

    private EntityRepository $productRepository;
    private EntityRepository $mediaRepository;
    private EntityRepository $productMediaRepository;
    private EntityRepository $mediaFolderRepository;
    private FileSaver $fileSaver;
    private const FILENAME_PREFIX = 'imported_';

    public function __construct(
        EntityRepository $productRepository,
        EntityRepository $mediaRepository,
        EntityRepository $productMediaRepository,
        EntityRepository $mediaFolderRepository,
        FileSaver $fileSaver
    ) {
        parent::__construct();
        $this->productRepository = $productRepository;
        $this->mediaRepository = $mediaRepository;
        $this->productMediaRepository = $productMediaRepository;
        $this->mediaFolderRepository = $mediaFolderRepository;
        $this->fileSaver = $fileSaver;
    }

    protected function configure(): void
    {
        $this
            ->setDescription('Scans a folder for images, adds a prefix, and assigns them to products, reusing existing media.')
            ->addArgument('directory', InputArgument::REQUIRED, 'The absolute path to the directory to scan.')
            ->addOption('dry-run', null, InputOption::VALUE_NONE, 'Perform a dry run without changing any data.')
            ->addOption('folder-id', null, InputOption::VALUE_REQUIRED, 'The ID of the media folder to upload new images into.');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $directory = $input->getArgument('directory');
        $isDryRun = $input->getOption('dry-run');
        $folderId = $input->getOption('folder-id');
        $context = Context::createDefaultContext();
        $mediaFolder = null;

        if ($isDryRun) {
            $io->warning('--- DRY RUN MODE --- No changes will be saved.');
        }

        if ($folderId) {
            if (!Uuid::isValid($folderId)) {
                $io->error(sprintf('The provided folder-id "%s" is not a valid UUID.', $folderId));
                return Command::FAILURE;
            }

            /** @var ?MediaFolderEntity $mediaFolder */
            $mediaFolder = $this->mediaFolderRepository->search(new Criteria([$folderId]), $context)->get($folderId);
            if (!$mediaFolder) {
                $io->error(sprintf('The media folder with ID "%s" could not be found.', $folderId));
                return Command::FAILURE;
            }
            $io->info(sprintf('New images will be uploaded to folder: "%s"', $mediaFolder->getName()));
        }

        if (!is_dir($directory) || !is_readable($directory)) {
            $io->error(sprintf('The directory "%s" does not exist or is not readable.', $directory));
            return Command::FAILURE;
        }

        $io->title('Starting Image Import');
        $io->text('Scanning directory: ' . $directory);

        $finder = new Finder();
        $finder->files()->in($directory)->name('/^.+_\d+\.(jpg|jpeg|png|gif)$/i');

        if (!$finder->hasResults()) {
            $io->warning('No images found matching the required pattern (e.g., FILENAME_1.jpg).');
            return Command::SUCCESS;
        }

        $io->progressStart($finder->count());

        foreach ($finder as $file) {
            $io->progressAdvance();
            $io->writeln('');
            $io->writeln(sprintf('Processing file: <info>%s</info>', $file->getRelativePathname()));

            $parentFolderName = basename($file->getPath());
            $targetProductNumbers = array_map('trim', explode('+', $parentFolderName));
            $fileNameWithoutExt = $file->getFilenameWithoutExtension();
            $parts = explode('_', $fileNameWithoutExt);

            if (count($parts) < 2 || !ctype_digit($parts[count($parts) - 1])) {
                $io->writeln(sprintf(' <fg=yellow>└ Skipping: Filename does not end with `_NUMBER` (e.g., name_1.jpg).</>'));
                continue;
            }
            $imagePosition = (int)array_pop($parts);

            // --- Find or Create Media ---
            $mediaId = null;
            if (!$isDryRun) {
                $mediaId = $this->findOrCreateMediaAndGetId($file, $folderId, $context, $io);
                if ($mediaId === null) {
                    continue;
                }
            } else {
                $prefixedName = self::FILENAME_PREFIX . $file->getFilenameWithoutExtension();
                $io->writeln(" <fg=cyan>└ [Dry Run] Would search for media named '{$prefixedName}'. If not found, would upload.</>");
                if ($folderId && $mediaFolder) {
                    $io->writeln(sprintf(" <fg=cyan>   └ [Dry Run] Would upload to folder: '%s'</>", $mediaFolder->getName()));
                }
            }

            // --- Assign to Products ---
            foreach ($targetProductNumbers as $productNumber) {
                $product = $this->findProductByNumber($productNumber, $context);
                if (!$product) {
                    $io->writeln(sprintf(' <fg=yellow>└ Skipping assignment for product "%s": Not found.</>', $productNumber));
                    continue;
                }

                if (!$isDryRun) {
                    // We need a valid mediaId to proceed
                    if ($mediaId) {
                        $this->createProductMediaAssociation($product, $mediaId, $imagePosition, $context, $io);
                    }
                } else {
                    $io->writeln(sprintf(' <fg=cyan>└ [Dry Run] Would associate image with product "%s" at position %d.</>', $productNumber, $imagePosition));
                    if ($imagePosition === 1) {
                         $io->writeln(' <fg=cyan>   └ [Dry Run] Would set as cover image.</>');
                    }
                }
            }
        }

        $io->progressFinish();
        $io->success('Image import process finished.');
        return Command::SUCCESS;
    }

    private function findProductByNumber(string $productNumber, Context $context): ?ProductEntity
    {
        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('productNumber', $productNumber));
        $criteria->setLimit(1);

        /** @var ?ProductEntity $product */
        $product = $this->productRepository->search($criteria, $context)->first();
        return $product;
    }

    /**
     * Checks if media with a prefixed name exists. If so, returns its ID.
     * If not, it uploads the file with the prefixed name and returns the new ID.
     *
     * @param \SplFileInfo $file The file to process.
     * @param string|null $folderId The optional ID of the media folder to upload to.
     * @param Context $context The current context.
     * @param SymfonyStyle $io The console output style.
     * @return string|null The ID of the found or created media, or null on failure.
     */
    private function findOrCreateMediaAndGetId(\SplFileInfo $file, ?string $folderId, Context $context, SymfonyStyle $io): ?string
    {
        $prefixedFileName = self::FILENAME_PREFIX . $file->getFilenameWithoutExtension();

        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('fileName', $prefixedFileName));
        $criteria->setLimit(1);

        /** @var ?MediaEntity $existingMedia */
        $existingMedia = $this->mediaRepository->search($criteria, $context)->first();

        if ($existingMedia) {
            $io->writeln(sprintf(' <info>└ Found existing media: "%s". Reusing ID: %s</info>', $prefixedFileName, $existingMedia->getId()));
            return $existingMedia->getId();
        }

        $io->writeln(sprintf(' <info>└ No existing media found. Uploading as new: "%s"</info>', $prefixedFileName));
        try {
            $mediaId = Uuid::randomHex();

            $mediaData = ['id' => $mediaId];
            if ($folderId) {
                $mediaData['mediaFolderId'] = $folderId;
            }
            $this->mediaRepository->create([$mediaData], $context);

            $mediaFile = new MediaFile(
                $file->getPathname(),
                mime_content_type($file->getPathname()),
                $file->getExtension(),
                $file->getSize()
            );

            $this->fileSaver->persistFileToMedia($mediaFile, $prefixedFileName, $mediaId, $context);

            $io->writeln(sprintf('   <info>└ Upload successful. New Media ID: %s</info>', $mediaId));
            return $mediaId;
        } catch (\Exception $e) {
            $io->error(sprintf('Failed to upload file "%s". Error: %s', $file->getRelativePathname(), $e->getMessage()));
            return null;
        }
    }

    private function createProductMediaAssociation(ProductEntity $product, string $mediaId, int $position, Context $context, SymfonyStyle $io): void
    {
        try {
            $criteria = new Criteria();
            $criteria->addFilter(new EqualsFilter('productId', $product->getId()));
            $criteria->addFilter(new EqualsFilter('mediaId', $mediaId));
            if ($this->productMediaRepository->searchIds($criteria, $context)->getTotal() > 0) {
                $io->writeln(sprintf(' <fg=yellow>└ Association already exists for product "%s". Skipping.</>', $product->getProductNumber()));
                return;
            }

            $productMediaId = Uuid::randomHex();
            $this->productMediaRepository->create([
                [
                    'id' => $productMediaId,
                    'productId' => $product->getId(),
                    'mediaId' => $mediaId,
                    'position' => $position,
                ]
            ], $context);
            $io->writeln(sprintf(' <info>└ Associated with product "%s" at position %d.</info>', $product->getProductNumber(), $position));

            /*if ($position === 1) {
                $this->productRepository->update([['id' => $product->getId(), 'coverId' => $productMediaId]], $context);
                $io->writeln('   <info>└ Set as cover image.</info>');
            }*/
        } catch (\Exception $e) {
            $io->error(sprintf('Failed to associate media with product "%s". Error: %s', $product->getProductNumber(), $e->getMessage()));
        }
    }
}
